# Changelog

All notable changes to this project are documented here.

## [1.0.0] — 2025

Initial release. Real-time Web Cache Poisoning / Deception / CPDoS scanner for Burp Suite
(Montoya API), with a knowledge base of **101 techniques** extracted from ~99 research
reports, PortSwigger labs, HackTricks, PayloadsAllTheThings and ~60 HackerOne reports.

### Engine
- Real-time Proxy-history poller + Import HTTP History + Import Site map.
- Two worker threads, per-endpoint de-duplication, Start/Pause/Resume/Stop.
- Rate limiting (requests/minute) and a hard total-request cap.

### Detection
- **Poisoning:** unkeyed host/scheme/port/URL-override headers, scheme-combo open redirects,
  unkeyed cookies, fat GET, parameter cloaking, unkeyed query params, cache-key injection
  (unkeyed port / encoded parameter), cache-key oracle (Akamai `Pragma`), Vary awareness.
- **Deception:** static extensions (incl. `.avif` armor bypass), path mapping, per-framework
  delimiters, normalization/traversal, static directories, anonymous-retrieval confirmation.
- **CPDoS:** HHO/HMC/HMO, method override, dud port, bad `Transfer-Encoding`/`Range`/
  `Accept-Encoding`, oversized headers, malformed query.

### Hardening (four audit rounds — see `docs/AUDIT-*.md`)
- **Round 1 (functional):** activated 3 previously-dormant technique lists (port / method-override
  / cache-key-oracle); added cache-key injection, PURGE and oracle probes; removed narrow caps so
  every technique is applied.
- **Round 2 (production):** bounded memory (ring-buffered tables, trimmed log, bounded queue,
  capped body analysis); made PURGE opt-in; randomised the cache-buster parameter name; added a
  scope-off warning; null-safe request/response construction.
- **Round 3 (detection accuracy):** fixed `Cache-Control` parsing so `max-age` is not matched
  inside `s-maxage` and shared-cache `s-maxage` is honoured (was a false negative); strip a full
  set of auth headers for a genuinely anonymous deception confirmation (was a false-positive
  Critical).
- **Round 4 (UI / static analysis):** stop resetting id counters on Clear (avoids id collision
  with in-flight rows); stop the counter timer on unload (avoids a leak); static-analysis sweep
  (exception handling, casts, NPEs, loop termination, EDT safety) — clean.

### Known limitations
- Detection is heuristic — findings are candidates to verify manually.
- No explicit per-request timeout (relies on Burp project network timeouts).
- Some platform-specific techniques are documented but not automated (Sitecore, Apache Traffic
  Server fragment CVE-2021-27577, host-header casing, 403-via-Authorization on buckets,
  poisoning via HTTP request smuggling).
- End-to-end validation against a live target requires loading in Burp.
