# Security & Responsible Use

## Authorised testing only

Cache Hunter generates and sends **attack traffic** (spoofed headers, path variants, malformed
requests, optional PURGE). Only run it against:

- systems you own, or
- targets for which you have **explicit written authorisation** (an in-scope bug-bounty program,
  a signed penetration-test engagement, or intentionally vulnerable labs such as the
  PortSwigger Web Security Academy).

Testing systems without authorisation may be illegal in your jurisdiction. You are solely
responsible for how you use this tool.

## Built-in safety measures

- **Random cache-buster** on every proof-of-concept probe — a proof only ever populates the
  tool's own cache key, not the key served to real users.
- **Only in-scope** is enabled by default; disabling it shows a warning.
- **PURGE is opt-in** (off by default) behind a confirmation dialog, because on path-based purge
  servers it can flush a cache entry used by real users.
- **Rate limiting** (requests/minute) and a **hard request cap** bound the traffic you generate.
- **Memory bounds** and **clean teardown** on unload.

## Recommendations

- Use a **low-privilege test account** when probing cache deception (the tool may cache its own
  authenticated response under its private buster key).
- Set sensible **network timeouts** in your Burp project options.
- Start with a **low request limit / rate** and increase only as needed.

## Reporting a vulnerability in this tool

If you find a security issue in Cache Hunter itself (for example, a way it could harm a target
beyond the documented probes), please open a private security advisory or an issue describing the
problem and reproduction steps.
