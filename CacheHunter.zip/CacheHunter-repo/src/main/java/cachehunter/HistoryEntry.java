package cachehunter;

import burp.api.montoya.http.message.HttpRequestResponse;

/**
 * A row in a module's HTTP history table. Two kinds:
 *  - ORIGINAL: the base request pulled from Burp (Proxy history / Site map / manual).
 *  - TEST:     a request the engine generated & sent while applying a technique.
 */
public class HistoryEntry {
    public enum Type { ORIGINAL, TEST }

    public final int id;
    public final Type type;
    public final String module;
    public final String technique;      // "-" for originals
    public final String injectionPoint; // header/cookie/path variant, "-" for originals
    public final String method;
    public final String url;
    public final int status;            // -1 if no response
    public final String cacheStatus;    // HIT / MISS / CACHEABLE / -
    public final boolean reflected;
    public final String note;
    public final HttpRequestResponse rr;
    public final int parentId;          // for TEST rows: id of the ORIGINAL it derives from (-1 otherwise)

    public HistoryEntry(int id, Type type, String module, String technique, String injectionPoint,
                        String method, String url, int status, String cacheStatus, boolean reflected,
                        String note, HttpRequestResponse rr, int parentId) {
        this.id = id;
        this.type = type;
        this.module = module;
        this.technique = technique;
        this.injectionPoint = injectionPoint;
        this.method = method;
        this.url = url;
        this.status = status;
        this.cacheStatus = cacheStatus;
        this.reflected = reflected;
        this.note = note;
        this.rr = rr;
        this.parentId = parentId;
    }
}
