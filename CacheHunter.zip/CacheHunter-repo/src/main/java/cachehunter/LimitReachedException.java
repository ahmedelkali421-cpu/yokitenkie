package cachehunter;

/** Thrown when the configured total request limit has been hit, to unwind the current scan. */
class LimitReachedException extends RuntimeException {
    LimitReachedException() { super("request limit reached"); }
}
