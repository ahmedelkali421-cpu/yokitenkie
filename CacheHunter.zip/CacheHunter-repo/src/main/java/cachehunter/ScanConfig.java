package cachehunter;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicReference;

/**
 * Central, thread-safe configuration + live counters shared by the engine and the UI.
 * All fields are read live so changes in the control bar take effect immediately.
 */
public class ScanConfig {

    public enum State { STOPPED, RUNNING, PAUSED }

    // ---- production safety limits (bound memory / CPU regardless of Request-limit) ----
    public static final int MAX_TABLE_ROWS = 15_000;   // per module HTTP-history table (ring buffer)
    public static final int MAX_FINDING_ROWS = 5_000;  // per module findings table
    public static final int MAX_QUEUE = 10_000;        // bounded ingestion queue
    public static final int MAX_LOG_CHARS = 300_000;   // Event Log trim threshold
    public static final int MAX_BODY_SCAN = 500_000;   // only analyse first N chars of a body

    // ---- engine state ----
    private final AtomicReference<State> state = new AtomicReference<>(State.STOPPED);

    // ---- attacker-controlled domain (default evil.com) ----
    private final AtomicReference<String> attackerDomain = new AtomicReference<>("evil.com");

    // ---- rate / volume limits ----
    private final AtomicInteger requestsPerMinute = new AtomicInteger(120);   // throttle
    private final AtomicInteger requestLimit      = new AtomicInteger(5000);  // hard cap on total sent

    // ---- behaviour toggles ----
    private final AtomicBoolean onlyInScope   = new AtomicBoolean(true);
    private final AtomicBoolean skipNonGet    = new AtomicBoolean(true);
    private final AtomicBoolean autoWatch     = new AtomicBoolean(true);   // poll proxy history every 3s
    private final AtomicBoolean probePoison   = new AtomicBoolean(true);
    private final AtomicBoolean probeDeception= new AtomicBoolean(true);
    private final AtomicBoolean probeDos      = new AtomicBoolean(true);
    private final AtomicBoolean enablePurge   = new AtomicBoolean(false);  // destructive verb - opt-in only
    private final AtomicBoolean verbose       = new AtomicBoolean(true);

    // ---- live counters ----
    private final AtomicInteger probesSent = new AtomicInteger(0);
    private final AtomicInteger findings   = new AtomicInteger(0);
    private final AtomicInteger queueSize  = new AtomicInteger(0);

    // ---- editable technique lists (seeded from TechniqueLibrary, live-editable in the Deception tab) ----
    public final CopyOnWriteArrayList<String> staticExtensions = new CopyOnWriteArrayList<>();
    public final CopyOnWriteArrayList<String> delimiters       = new CopyOnWriteArrayList<>();
    public final CopyOnWriteArrayList<String> staticDirs       = new CopyOnWriteArrayList<>();
    public final CopyOnWriteArrayList<String> sensitiveMarkers = new CopyOnWriteArrayList<>();

    public ScanConfig() {
        staticExtensions.addAll(TechniqueLibrary.STATIC_EXTENSIONS);
        delimiters.addAll(TechniqueLibrary.DECEPTION_DELIMITERS);
        staticDirs.addAll(TechniqueLibrary.STATIC_DIRECTORIES);
        sensitiveMarkers.addAll(TechniqueLibrary.SENSITIVE_MARKERS);
    }

    // ---- state ----
    public State state()              { return state.get(); }
    public void  setState(State s)    { state.set(s); }
    public boolean isRunning()        { return state.get() == State.RUNNING; }
    public boolean isPaused()         { return state.get() == State.PAUSED; }
    public boolean isStopped()        { return state.get() == State.STOPPED; }

    // ---- domain ----
    public String attackerDomain()            { return attackerDomain.get(); }
    public void   setAttackerDomain(String d) { attackerDomain.set(d == null || d.isBlank() ? "evil.com" : d.trim()); }

    // ---- limits ----
    public int  requestsPerMinute()        { return Math.max(1, requestsPerMinute.get()); }
    public void setRequestsPerMinute(int v){ requestsPerMinute.set(Math.max(1, v)); }
    public int  requestLimit()             { return requestLimit.get(); }
    public void setRequestLimit(int v)     { requestLimit.set(Math.max(1, v)); }

    // ---- toggles ----
    public boolean onlyInScope()            { return onlyInScope.get(); }
    public void    setOnlyInScope(boolean b){ onlyInScope.set(b); }
    public boolean skipNonGet()             { return skipNonGet.get(); }
    public void    setSkipNonGet(boolean b) { skipNonGet.set(b); }
    public boolean autoWatch()              { return autoWatch.get(); }
    public void    setAutoWatch(boolean b)  { autoWatch.set(b); }
    public boolean probePoison()            { return probePoison.get(); }
    public void    setProbePoison(boolean b){ probePoison.set(b); }
    public boolean probeDeception()             { return probeDeception.get(); }
    public void    setProbeDeception(boolean b) { probeDeception.set(b); }
    public boolean probeDos()               { return probeDos.get(); }
    public void    setProbeDos(boolean b)   { probeDos.set(b); }
    public boolean enablePurge()            { return enablePurge.get(); }
    public void    setEnablePurge(boolean b){ enablePurge.set(b); }
    public boolean verbose()                { return verbose.get(); }
    public void    setVerbose(boolean b)    { verbose.set(b); }

    // ---- counters ----
    public int  probesSent()          { return probesSent.get(); }
    public int  incProbes()           { return probesSent.incrementAndGet(); }
    public boolean limitReached()     { return probesSent.get() >= requestLimit.get(); }
    public int  findings()            { return findings.get(); }
    public int  incFindings()         { return findings.incrementAndGet(); }
    public int  queueSize()           { return queueSize.get(); }
    public void setQueueSize(int v)   { queueSize.set(Math.max(0, v)); }
    public int  incQueue()            { return queueSize.incrementAndGet(); }
    public int  decQueue()            { return queueSize.updateAndGet(x -> Math.max(0, x - 1)); }

    public void resetCounters() {
        probesSent.set(0);
        findings.set(0);
        queueSize.set(0);
    }

    public List<String> snapshotExtensions() { return new ArrayList<>(staticExtensions); }
    public List<String> snapshotDelimiters() { return new ArrayList<>(delimiters); }
    public List<String> snapshotDirs()        { return new ArrayList<>(staticDirs); }
    public List<String> snapshotMarkers()     { return new ArrayList<>(sensitiveMarkers); }
}
