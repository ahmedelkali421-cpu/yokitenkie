package cachehunter;

import javax.swing.*;
import javax.swing.table.AbstractTableModel;
import java.awt.*;
import java.util.List;

/** Read-only browser of every technique/payload extracted from the corpus. */
public class TechniqueDbPanel extends JPanel {

    public TechniqueDbPanel() {
        super(new BorderLayout());
        List<Technique> all = TechniqueLibrary.catalogue();
        JTable table = new JTable(new Model(all));
        table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
        int[] w = {150, 190, 210, 300, 380, 220};
        for (int i = 0; i < w.length; i++) table.getColumnModel().getColumn(i).setPreferredWidth(w[i]);
        JScrollPane sp = new JScrollPane(table);
        sp.setBorder(BorderFactory.createTitledBorder(
                "Extracted techniques database — " + all.size()
                        + " entries (headers, cookies, params, delimiters, DoS primitives)"));
        add(sp, BorderLayout.CENTER);

        JLabel note = new JLabel("  Distilled from 99 reports/labs: PortSwigger Research & Academy, "
                + "HackTricks, PayloadsAllTheThings, ~60 HackerOne reports.");
        note.setForeground(new Color(0x555555));
        add(note, BorderLayout.SOUTH);
    }

    private static class Model extends AbstractTableModel {
        private final List<Technique> rows;
        private final String[] cols = {"Kind", "Category", "Name", "Payload", "Description", "Source"};
        Model(List<Technique> rows) { this.rows = rows; }
        @Override public int getRowCount() { return rows.size(); }
        @Override public int getColumnCount() { return cols.length; }
        @Override public String getColumnName(int c) { return cols[c]; }
        @Override public Object getValueAt(int r, int c) {
            Technique t = rows.get(r);
            switch (c) {
                case 0: return t.kind;
                case 1: return t.category;
                case 2: return t.name;
                case 3: return t.payload;
                case 4: return t.description;
                case 5: return t.source;
                default: return "";
            }
        }
    }
}
