package cachehunter;

import burp.api.montoya.MontoyaApi;
import burp.api.montoya.http.message.HttpRequestResponse;
import burp.api.montoya.http.message.requests.HttpRequest;
import burp.api.montoya.http.message.responses.HttpResponse;
import burp.api.montoya.proxy.ProxyHttpRequestResponse;

import java.util.List;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executors;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Orchestrates real-time hunting: pulls base requests from Burp (live Proxy-history poller +
 * manual Site-map / history import), de-duplicates them per endpoint, and hands each to the
 * poisoning and deception scanners on a small worker pool, honouring start/pause/resume/stop
 * and the rate / total-request limits.
 */
public class ScanEngine {

    private final MontoyaApi api;
    private final ScanConfig cfg;
    private final Logger log;
    private final Scanners scanners;

    private ModuleSink poisonSink;
    private ModuleSink deceptionSink;

    private final LinkedBlockingQueue<HttpRequestResponse> queue = new LinkedBlockingQueue<>(ScanConfig.MAX_QUEUE);
    private final Set<String> seen = ConcurrentHashMap.newKeySet();
    private final AtomicInteger lastProxyId = new AtomicInteger(0);
    private final AtomicBoolean workersStarted = new AtomicBoolean(false);
    private volatile boolean alive = true;

    private final ScheduledExecutorService poller = Executors.newSingleThreadScheduledExecutor(r -> {
        Thread t = new Thread(r, "CacheHunter-Poller");
        t.setDaemon(true);
        return t;
    });

    public ScanEngine(MontoyaApi api, ScanConfig cfg, Logger log, RateLimiter limiter) {
        this.api = api;
        this.cfg = cfg;
        this.log = log;
        Sender sender = new Sender(api, cfg, limiter, log);
        this.scanners = new Scanners(api, cfg, log, sender);
    }

    public void setSinks(ModuleSink poison, ModuleSink deception) {
        this.poisonSink = poison;
        this.deceptionSink = deception;
    }

    // ---- lifecycle controls ----
    public void start() {
        if (cfg.isRunning()) return;
        cfg.setState(ScanConfig.State.RUNNING);
        ensureWorkers();
        log.info("Engine STARTED  (domain=" + cfg.attackerDomain() + ", limit=" + cfg.requestLimit()
                + ", rate=" + cfg.requestsPerMinute() + "/min)");
    }

    public void pause() {
        if (!cfg.isRunning()) return;
        cfg.setState(ScanConfig.State.PAUSED);
        log.info("Engine PAUSED");
    }

    public void resume() {
        if (!cfg.isPaused()) return;
        cfg.setState(ScanConfig.State.RUNNING);
        log.info("Engine RESUMED");
    }

    public void stop() {
        cfg.setState(ScanConfig.State.STOPPED);
        int drained = queue.size();
        queue.clear();
        cfg.setQueueSize(0);
        log.info("Engine STOPPED (dropped " + drained + " queued)");
    }

    void stopFromLimit() {
        cfg.setState(ScanConfig.State.STOPPED);
        queue.clear();
        cfg.setQueueSize(0);
        log.warn("Request limit (" + cfg.requestLimit() + ") reached - engine stopped.");
    }

    public void clearQueue() {
        queue.clear();
        seen.clear();
        cfg.setQueueSize(0);
        log.info("Queue + dedup cleared.");
    }

    public void shutdown() {
        alive = false;
        cfg.setState(ScanConfig.State.STOPPED);
        poller.shutdownNow();
    }

    // ---- ingestion ----
    private void startPoller() {
        poller.scheduleWithFixedDelay(() -> {
            try {
                if (!cfg.autoWatch() || !cfg.isRunning()) return;
                List<ProxyHttpRequestResponse> hist = api.proxy().history();
                for (ProxyHttpRequestResponse p : hist) {
                    if (p.id() <= lastProxyId.get()) continue;
                    lastProxyId.updateAndGet(x -> Math.max(x, p.id()));
                    if (p.finalRequest() == null || p.originalResponse() == null) continue;
                    HttpRequestResponse rr = HttpRequestResponse.httpRequestResponse(
                            p.finalRequest(), p.originalResponse());
                    enqueue(rr, "proxy");
                }
            } catch (Throwable t) {
                if (cfg.verbose()) log.error("poller: " + t.getMessage());
            }
        }, 1, 3, TimeUnit.SECONDS);
    }

    /** Import everything currently in the Proxy HTTP history. */
    public int importProxyHistory() {
        int n = 0;
        try {
            for (ProxyHttpRequestResponse p : api.proxy().history()) {
                lastProxyId.updateAndGet(x -> Math.max(x, p.id()));
                if (p.finalRequest() == null || p.originalResponse() == null) continue;
                HttpRequestResponse rr = HttpRequestResponse.httpRequestResponse(
                        p.finalRequest(), p.originalResponse());
                if (enqueue(rr, "import-history")) n++;
            }
        } catch (Throwable t) {
            log.error("import history: " + t.getMessage());
        }
        log.info("Imported " + n + " requests from Proxy history.");
        return n;
    }

    /** Import the Target Site map (static assets + pages) so scanning targets real endpoints. */
    public int importSiteMap() {
        int n = 0;
        try {
            for (HttpRequestResponse rr : api.siteMap().requestResponses()) {
                if (enqueue(rr, "sitemap")) n++;
            }
        } catch (Throwable t) {
            log.error("import sitemap: " + t.getMessage());
        }
        log.info("Imported " + n + " requests from Target Site map.");
        return n;
    }

    private boolean enqueue(HttpRequestResponse rr, String src) {
        if (rr == null) return false;
        HttpRequest req = rr.request();
        if (req == null) return false;
        if (cfg.skipNonGet() && !"GET".equalsIgnoreCase(req.method())) return false;
        if (cfg.onlyInScope()) {
            try { if (!api.scope().isInScope(req.url())) return false; } catch (Exception ignored) {}
        }
        String sig = signature(req);
        if (!seen.add(sig)) return false;    // already scanned this endpoint
        if (!queue.offer(rr)) {              // bounded queue full - drop + un-mark so it can be retried later
            seen.remove(sig);
            if (cfg.verbose()) log.warn("queue full (" + ScanConfig.MAX_QUEUE + ") - skipped " + req.url());
            return false;
        }
        cfg.incQueue();
        if (cfg.verbose()) log.info("queued [" + src + "] " + req.method() + " " + req.url());
        return true;
    }

    private static String signature(HttpRequest req) {
        String host;
        try { host = req.httpService().host(); } catch (Exception e) { host = "?"; }
        return req.method() + " " + host + " " + safe(req.pathWithoutQuery());
    }

    private static String safe(String s) { return s == null ? "/" : s; }

    // ---- workers ----
    private void ensureWorkers() {
        if (!workersStarted.compareAndSet(false, true)) return;
        startPoller();
        int n = 2;
        for (int i = 0; i < n; i++) {
            Thread w = new Thread(this::workerLoop, "CacheHunter-Worker-" + i);
            w.setDaemon(true);
            w.start();
        }
        log.info("Started " + n + " worker threads.");
    }

    private void workerLoop() {
        while (alive) {
            if (!cfg.isRunning()) { sleep(150); continue; }
            HttpRequestResponse base;
            try {
                base = queue.poll(200, TimeUnit.MILLISECONDS);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                break;
            }
            if (base == null) continue;
            cfg.decQueue();
            try {
                process(base);
            } catch (LimitReachedException le) {
                stopFromLimit();
            } catch (Throwable t) {
                log.error("worker: " + t);
            }
        }
    }

    private void process(HttpRequestResponse base) {
        if (cfg.probePoison() && poisonSink != null) {
            HistoryEntry o = original(poisonSink, base);
            poisonSink.addOriginal(o);
            scanners.scanPoison(base, o.id, poisonSink);
        }
        if (cfg.probeDeception() && deceptionSink != null) {
            HistoryEntry o = original(deceptionSink, base);
            deceptionSink.addOriginal(o);
            scanners.scanDeception(base, o.id, deceptionSink);
        }
    }

    private static HistoryEntry original(ModuleSink sink, HttpRequestResponse rr) {
        HttpRequest rq = rr.request();
        HttpResponse rs = rr.response();
        int status = rs != null ? rs.statusCode() : -1;
        String method = rq != null ? rq.method() : "?";
        String url = rq != null ? rq.url() : "";
        return new HistoryEntry(sink.nextHistoryId(), HistoryEntry.Type.ORIGINAL, sink.moduleName(),
                "-", "-", method, url, status, CacheAnalyzer.label(rs), false, "base request", rr, -1);
    }

    private static void sleep(long ms) {
        try { Thread.sleep(ms); } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
    }
}
