package cachehunter;

import burp.api.montoya.MontoyaApi;
import burp.api.montoya.http.message.HttpRequestResponse;
import burp.api.montoya.ui.editor.EditorOptions;
import burp.api.montoya.ui.editor.HttpRequestEditor;
import burp.api.montoya.ui.editor.HttpResponseEditor;

import javax.swing.*;
import javax.swing.table.AbstractTableModel;
import javax.swing.table.DefaultTableCellRenderer;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * One self-contained module view (used for both "Cache Poisoning" and "Cache Deception").
 * Layout:  [ HTTP history table | Findings table ]  over  [ Original/Tested req+resp viewers ].
 * Implements {@link ModuleSink} so the engine streams rows straight into it (on the EDT).
 */
public class ModulePanel extends JPanel implements ModuleSink {

    private final String moduleName;
    private final MontoyaApi api;

    private final AtomicInteger historyIds = new AtomicInteger(0);
    private final AtomicInteger findingIds = new AtomicInteger(0);

    private final HistoryModel historyModel = new HistoryModel();
    private final FindingModel findingModel = new FindingModel();
    private final JTable historyTable = new JTable(historyModel);
    private final JTable findingTable = new JTable(findingModel);

    private final HttpRequestEditor origReq;
    private final HttpResponseEditor origResp;
    private final HttpRequestEditor testReq;
    private final HttpResponseEditor testResp;
    private final JTextArea diffArea = new JTextArea();
    private final JTextArea techArea = new JTextArea();

    public ModulePanel(String moduleName, MontoyaApi api) {
        super(new BorderLayout());
        this.moduleName = moduleName;
        this.api = api;

        origReq  = api.userInterface().createHttpRequestEditor(EditorOptions.READ_ONLY);
        origResp = api.userInterface().createHttpResponseEditor(EditorOptions.READ_ONLY);
        testReq  = api.userInterface().createHttpRequestEditor(EditorOptions.READ_ONLY);
        testResp = api.userInterface().createHttpResponseEditor(EditorOptions.READ_ONLY);

        // ---- top: history + findings ----
        historyTable.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
        historyTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        historyTable.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) showHistorySelection();
        });
        historyTable.setDefaultRenderer(Object.class, new RowRenderer());
        setWidths(historyTable, new int[]{45, 70, 60, 420, 150, 150, 55, 90, 70});

        findingTable.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
        findingTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        findingTable.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) showFindingSelection();
        });
        findingTable.setDefaultRenderer(Object.class, new SeverityRenderer());
        setWidths(findingTable, new int[]{40, 80, 240, 200, 320, 80});

        JScrollPane histScroll = new JScrollPane(historyTable);
        histScroll.setBorder(BorderFactory.createTitledBorder("HTTP history — " + moduleName
                + " (originals + tests)"));
        JScrollPane findScroll = new JScrollPane(findingTable);
        findScroll.setBorder(BorderFactory.createTitledBorder("Findings"));

        JSplitPane top = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, histScroll, findScroll);
        top.setResizeWeight(0.62);

        // ---- bottom: viewers ----
        JTabbedPane viewers = new JTabbedPane();
        viewers.addTab("Original Req", origReq.uiComponent());
        viewers.addTab("Original Resp", origResp.uiComponent());
        viewers.addTab("Tested Req (Payload)", testReq.uiComponent());
        viewers.addTab("Tested Resp", testResp.uiComponent());
        diffArea.setEditable(false);
        diffArea.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 12));
        viewers.addTab("Diff (Original vs Tested)", new JScrollPane(diffArea));
        techArea.setEditable(false);
        techArea.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 12));
        viewers.addTab("Techniques applied", new JScrollPane(techArea));

        JSplitPane split = new JSplitPane(JSplitPane.VERTICAL_SPLIT, top, viewers);
        split.setResizeWeight(0.5);
        add(split, BorderLayout.CENTER);
    }

    private static void setWidths(JTable t, int[] w) {
        for (int i = 0; i < w.length && i < t.getColumnModel().getColumnCount(); i++)
            t.getColumnModel().getColumn(i).setPreferredWidth(w[i]);
    }

    // ---- selection wiring ----
    private void showHistorySelection() {
        int row = historyTable.getSelectedRow();
        if (row < 0 || row >= historyModel.rows.size()) return;
        HistoryEntry e = historyModel.rows.get(historyTable.convertRowIndexToModel(row));
        if (e.type == HistoryEntry.Type.ORIGINAL) {
            setReqResp(origReq, origResp, e.rr);
            clear(testReq, testResp);
            techArea.setText(techniquesFor(e.id));
        } else {
            setReqResp(testReq, testResp, e.rr);
            HistoryEntry parent = historyModel.findById(e.parentId);
            if (parent != null) setReqResp(origReq, origResp, parent.rr);
            diffArea.setText(buildDiff(parent, e));
        }
    }

    private void showFindingSelection() {
        int row = findingTable.getSelectedRow();
        if (row < 0 || row >= findingModel.rows.size()) return;
        Finding f = findingModel.rows.get(findingTable.convertRowIndexToModel(row));
        if (f.attack != null) setReqResp(testReq, testResp, f.attack);
        if (f.confirm != null) setReqResp(origReq, origResp, f.confirm);
        diffArea.setText("FINDING #" + f.id + "  [" + f.severity + "]\n"
                + "Technique : " + f.technique + "\n"
                + "Injection : " + f.injectionPoint + "\n"
                + "Host      : " + f.host + "\n"
                + "URL       : " + f.url + "\n"
                + "Cache     : " + f.cacheStatus + "\n\n"
                + "Evidence  : " + f.evidence + "\n\n"
                + "Top viewer tabs show: Tested Req/Resp = attack request, Original Req/Resp = confirmation request.");
    }

    private String techniquesFor(int originalId) {
        StringBuilder sb = new StringBuilder("Techniques applied to original #" + originalId + ":\n\n");
        int n = 0;
        for (HistoryEntry e : historyModel.rows) {
            if (e.type == HistoryEntry.Type.TEST && e.parentId == originalId) {
                sb.append(String.format("  %-38s %-22s status=%-4s cache=%-9s %s%n",
                        e.technique, e.injectionPoint, e.status < 0 ? "-" : e.status,
                        e.cacheStatus, e.reflected ? "[REFLECTED]" : e.note));
                n++;
            }
        }
        if (n == 0) sb.append("  (still scanning or no probes recorded yet)\n");
        return sb.toString();
    }

    private static String buildDiff(HistoryEntry orig, HistoryEntry test) {
        StringBuilder sb = new StringBuilder();
        sb.append("TECHNIQUE : ").append(test.technique).append('\n');
        sb.append("INJECTION : ").append(test.injectionPoint).append('\n');
        sb.append("NOTE      : ").append(test.note).append("\n\n");
        int os = orig != null ? orig.status : -1;
        sb.append("Original status : ").append(os < 0 ? "-" : os)
                .append("    cache=").append(orig != null ? orig.cacheStatus : "-").append('\n');
        sb.append("Tested   status : ").append(test.status < 0 ? "-" : test.status)
                .append("    cache=").append(test.cacheStatus).append('\n');
        sb.append("Reflected       : ").append(test.reflected).append('\n');
        return sb.toString();
    }

    private void setReqResp(HttpRequestEditor re, HttpResponseEditor rp, HttpRequestResponse rr) {
        try {
            if (rr != null && rr.request() != null) re.setRequest(rr.request());
            if (rr != null && rr.response() != null) rp.setResponse(rr.response());
        } catch (Exception ignored) {}
    }

    private void clear(HttpRequestEditor re, HttpResponseEditor rp) {
        try { re.setRequest(null); } catch (Exception ignored) {}
    }

    public void clearAll() {
        SwingUtilities.invokeLater(() -> {
            historyModel.clear();
            findingModel.clear();
            // NOTE: intentionally do NOT reset historyIds/findingIds — they must stay monotonic so
            // rows generated by workers still in flight during a Clear can never collide with new ids.
            diffArea.setText("");
            techArea.setText("");
        });
    }

    // ==================== ModuleSink ====================
    @Override public String moduleName() { return moduleName; }
    @Override public int nextHistoryId() { return historyIds.incrementAndGet(); }
    @Override public int nextFindingId() { return findingIds.incrementAndGet(); }

    @Override public void addOriginal(HistoryEntry e) {
        SwingUtilities.invokeLater(() -> historyModel.add(e));
    }
    @Override public void addTest(HistoryEntry e) {
        SwingUtilities.invokeLater(() -> historyModel.add(e));
    }
    @Override public void addFinding(Finding f) {
        SwingUtilities.invokeLater(() -> findingModel.add(f));
    }

    // ==================== table models ====================
    private static class HistoryModel extends AbstractTableModel {
        private final List<HistoryEntry> rows = new ArrayList<>();
        private final String[] cols = {"#", "Type", "Method", "URL", "Technique", "Injection", "Status", "Cache", "Reflected"};
        void add(HistoryEntry e) {
            rows.add(e);
            int r = rows.size() - 1;
            fireTableRowsInserted(r, r);
            while (rows.size() > ScanConfig.MAX_TABLE_ROWS) {
                rows.remove(0);
                fireTableRowsDeleted(0, 0);
            }
        }
        void clear() { int n = rows.size(); rows.clear(); if (n > 0) fireTableRowsDeleted(0, n - 1); }
        HistoryEntry findById(int id) { for (HistoryEntry e : rows) if (e.id == id) return e; return null; }
        @Override public int getRowCount() { return rows.size(); }
        @Override public int getColumnCount() { return cols.length; }
        @Override public String getColumnName(int c) { return cols[c]; }
        @Override public Object getValueAt(int r, int c) {
            HistoryEntry e = rows.get(r);
            switch (c) {
                case 0: return e.id;
                case 1: return e.type == HistoryEntry.Type.ORIGINAL ? "ORIG" : "test";
                case 2: return e.method;
                case 3: return e.url;
                case 4: return e.technique;
                case 5: return e.injectionPoint;
                case 6: return e.status < 0 ? "-" : e.status;
                case 7: return e.cacheStatus;
                case 8: return e.reflected ? "yes" : "";
                default: return "";
            }
        }
    }

    private static class FindingModel extends AbstractTableModel {
        private final List<Finding> rows = new ArrayList<>();
        private final String[] cols = {"#", "Severity", "Technique", "Injection", "Evidence", "Cache"};
        void add(Finding f) {
            rows.add(f);
            int r = rows.size() - 1;
            fireTableRowsInserted(r, r);
            while (rows.size() > ScanConfig.MAX_FINDING_ROWS) {
                rows.remove(0);
                fireTableRowsDeleted(0, 0);
            }
        }
        void clear() { int n = rows.size(); rows.clear(); if (n > 0) fireTableRowsDeleted(0, n - 1); }
        @Override public int getRowCount() { return rows.size(); }
        @Override public int getColumnCount() { return cols.length; }
        @Override public String getColumnName(int c) { return cols[c]; }
        @Override public Object getValueAt(int r, int c) {
            Finding f = rows.get(r);
            switch (c) {
                case 0: return f.id;
                case 1: return f.severity;
                case 2: return f.technique;
                case 3: return f.injectionPoint;
                case 4: return f.evidence;
                case 5: return f.cacheStatus;
                default: return "";
            }
        }
    }

    // ==================== renderers ====================
    private class RowRenderer extends DefaultTableCellRenderer {
        @Override public Component getTableCellRendererComponent(JTable t, Object v, boolean sel,
                                                                 boolean foc, int row, int col) {
            Component c = super.getTableCellRendererComponent(t, v, sel, foc, row, col);
            int m = t.convertRowIndexToModel(row);
            if (m >= 0 && m < historyModel.rows.size()) {
                HistoryEntry e = historyModel.rows.get(m);
                if (!sel) {
                    if (e.type == HistoryEntry.Type.ORIGINAL) c.setForeground(new Color(0x1565C0));
                    else if (e.reflected) c.setForeground(new Color(0xC62828));
                    else c.setForeground(t.getForeground());
                }
            }
            return c;
        }
    }

    private class SeverityRenderer extends DefaultTableCellRenderer {
        @Override public Component getTableCellRendererComponent(JTable t, Object v, boolean sel,
                                                                 boolean foc, int row, int col) {
            Component c = super.getTableCellRendererComponent(t, v, sel, foc, row, col);
            int m = t.convertRowIndexToModel(row);
            if (m >= 0 && m < findingModel.rows.size() && !sel) {
                Finding f = findingModel.rows.get(m);
                c.setForeground(colorFor(f.severity));
            }
            return c;
        }
        private Color colorFor(Finding.Severity s) {
            switch (s) {
                case CRITICAL: return new Color(0xB71C1C);
                case HIGH:     return new Color(0xE53935);
                case MEDIUM:   return new Color(0xF57C00);
                case LOW:      return new Color(0x2E7D32);
                default:       return new Color(0x616161);
            }
        }
    }
}
