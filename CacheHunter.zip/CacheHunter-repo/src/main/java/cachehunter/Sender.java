package cachehunter;

import burp.api.montoya.MontoyaApi;
import burp.api.montoya.http.message.HttpRequestResponse;
import burp.api.montoya.http.message.requests.HttpRequest;

/**
 * Central choke point for all outbound requests: honours pause/stop, the requests/minute
 * throttle and the hard total-request cap. Every generated request goes through here.
 */
class Sender {
    private final MontoyaApi api;
    private final ScanConfig cfg;
    private final RateLimiter limiter;
    private final Logger log;

    Sender(MontoyaApi api, ScanConfig cfg, RateLimiter limiter, Logger log) {
        this.api = api;
        this.cfg = cfg;
        this.limiter = limiter;
        this.log = log;
    }

    /** Blocks while paused; aborts (returns null) if stopped; throws when the limit is reached. */
    HttpRequestResponse send(HttpRequest req) {
        // wait out pause
        while (cfg.isPaused()) {
            sleep(150);
        }
        if (cfg.isStopped()) return null;
        if (cfg.limitReached()) throw new LimitReachedException();
        try {
            limiter.acquire();
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            return null;
        }
        if (cfg.isStopped()) return null;
        cfg.incProbes();
        try {
            return api.http().sendRequest(req);
        } catch (Exception ex) {
            if (cfg.verbose()) log.error("send failed: " + ex.getMessage());
            return null;
        }
    }

    private static void sleep(long ms) {
        try { Thread.sleep(ms); } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
    }
}
