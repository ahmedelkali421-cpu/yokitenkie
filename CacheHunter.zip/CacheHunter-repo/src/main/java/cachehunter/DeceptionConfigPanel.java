package cachehunter;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Live-editable lists that drive the deception scanner: static extensions (seeded from the
 * CloudFlare/Akamai cacheable list), delimiter/normalization templates, static directories,
 * and the sensitive markers used to confirm a private-data leak. Editing here changes scanning
 * behaviour immediately (the engine reads these lists live from ScanConfig).
 */
public class DeceptionConfigPanel extends JPanel {

    private final ScanConfig cfg;
    private final JTextArea extArea = new JTextArea();
    private final JTextArea delimArea = new JTextArea();
    private final JTextArea dirArea = new JTextArea();
    private final JTextArea markerArea = new JTextArea();

    public DeceptionConfigPanel(ScanConfig cfg) {
        super(new BorderLayout(6, 6));
        this.cfg = cfg;

        JPanel grid = new JPanel(new GridLayout(2, 2, 8, 8));
        grid.add(wrap("Static extensions (one per line) — from CloudFlare/Akamai cacheable list + .avif armor bypass",
                extArea, cfg.snapshotExtensions()));
        grid.add(wrap("Delimiter / extension templates  {B}=base {EXT}=ext {RND}=rand",
                delimArea, cfg.snapshotDelimiters()));
        grid.add(wrap("Static directories (for normalization/traversal)", dirArea, cfg.snapshotDirs()));
        grid.add(wrap("Sensitive markers (confirm leaked private data)", markerArea, cfg.snapshotMarkers()));
        add(grid, BorderLayout.CENTER);

        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JButton apply = new JButton("Apply changes");
        JButton reset = new JButton("Reset to extracted defaults");
        apply.addActionListener(e -> apply());
        reset.addActionListener(e -> reset());
        buttons.add(apply);
        buttons.add(reset);
        JLabel hint = new JLabel("  Changes take effect on the next requests scanned.");
        hint.setForeground(new Color(0x616161));
        buttons.add(hint);
        add(buttons, BorderLayout.SOUTH);
    }

    private JComponent wrap(String title, JTextArea area, List<String> seed) {
        area.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 12));
        area.setText(String.join("\n", seed));
        JScrollPane sp = new JScrollPane(area);
        sp.setBorder(BorderFactory.createTitledBorder(title));
        return sp;
    }

    private void apply() {
        replace(cfg.staticExtensions, lines(extArea));
        replace(cfg.delimiters, lines(delimArea));
        replace(cfg.staticDirs, lines(dirArea));
        replace(cfg.sensitiveMarkers, lines(markerArea));
        JOptionPane.showMessageDialog(this, "Applied:\n"
                + cfg.staticExtensions.size() + " extensions, "
                + cfg.delimiters.size() + " templates, "
                + cfg.staticDirs.size() + " dirs, "
                + cfg.sensitiveMarkers.size() + " markers.");
    }

    private void reset() {
        extArea.setText(String.join("\n", TechniqueLibrary.STATIC_EXTENSIONS));
        delimArea.setText(String.join("\n", TechniqueLibrary.DECEPTION_DELIMITERS));
        dirArea.setText(String.join("\n", TechniqueLibrary.STATIC_DIRECTORIES));
        markerArea.setText(String.join("\n", TechniqueLibrary.SENSITIVE_MARKERS));
        apply();
    }

    private static List<String> lines(JTextArea a) {
        List<String> out = new ArrayList<>();
        for (String l : a.getText().split("\\R")) {
            String s = l.trim();
            if (!s.isEmpty()) out.add(s);
        }
        return out;
    }

    private static void replace(java.util.concurrent.CopyOnWriteArrayList<String> target, List<String> vals) {
        target.clear();
        target.addAll(vals);
    }
}
