package cachehunter;

/**
 * Simple interval-based limiter. Reads requests/minute live from ScanConfig so changing the
 * spinner takes effect immediately. Thread-safe: shared by all worker threads.
 */
public class RateLimiter {
    private final ScanConfig cfg;
    private long nextAllowedAt = 0L;

    public RateLimiter(ScanConfig cfg) { this.cfg = cfg; }

    /** Blocks until the next request is allowed under the current rate. */
    public synchronized void acquire() throws InterruptedException {
        long intervalMs = Math.max(1L, 60_000L / cfg.requestsPerMinute());
        long now = System.currentTimeMillis();
        if (now < nextAllowedAt) {
            Thread.sleep(nextAllowedAt - now);
            now = System.currentTimeMillis();
        }
        nextAllowedAt = now + intervalMs;
    }
}
