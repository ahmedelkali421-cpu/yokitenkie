package cachehunter;

import burp.api.montoya.http.message.HttpRequestResponse;

/** One detected issue, shown in a module's findings table and clickable to its evidence. */
public class Finding {
    public enum Severity { CRITICAL, HIGH, MEDIUM, LOW, INFO }

    public final int id;
    public final Severity severity;
    public final String module;        // "Cache Poisoning" | "Cache Deception"
    public final String technique;     // what was applied
    public final String host;
    public final String url;
    public final String injectionPoint;// header name / cookie / path variant
    public final String evidence;      // short human evidence string
    public final String cacheStatus;   // HIT / MISS / CACHEABLE / -
    public final HttpRequestResponse attack;   // the malicious request/response
    public final HttpRequestResponse confirm;  // the confirmation request/response (may be null)

    public Finding(int id, Severity severity, String module, String technique, String host, String url,
                   String injectionPoint, String evidence, String cacheStatus,
                   HttpRequestResponse attack, HttpRequestResponse confirm) {
        this.id = id;
        this.severity = severity;
        this.module = module;
        this.technique = technique;
        this.host = host;
        this.url = url;
        this.injectionPoint = injectionPoint;
        this.evidence = evidence;
        this.cacheStatus = cacheStatus;
        this.attack = attack;
        this.confirm = confirm;
    }
}
