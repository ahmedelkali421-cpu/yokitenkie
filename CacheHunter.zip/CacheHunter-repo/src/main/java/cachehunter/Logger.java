package cachehunter;

import burp.api.montoya.MontoyaApi;

import javax.swing.*;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.function.Consumer;

/** Simple logger: appends to the Event Log panel (via a consumer) and to Burp's output stream. */
public class Logger {
    private static final DateTimeFormatter TS = DateTimeFormatter.ofPattern("HH:mm:ss");
    private final MontoyaApi api;
    private volatile Consumer<String> uiSink;

    public Logger(MontoyaApi api) { this.api = api; }

    public void setUiSink(Consumer<String> sink) { this.uiSink = sink; }

    public void info(String msg)  { emit("[*] " + msg); }
    public void good(String msg)  { emit("[+] " + msg); }
    public void warn(String msg)  { emit("[!] " + msg); }
    public void error(String msg) { emit("[x] " + msg); if (api != null) api.logging().logToError(msg); }

    private void emit(String msg) {
        String line = "[" + LocalTime.now().format(TS) + "] " + msg;
        if (api != null) api.logging().logToOutput(line);
        Consumer<String> sink = uiSink;
        if (sink != null) SwingUtilities.invokeLater(() -> sink.accept(line));
    }
}
