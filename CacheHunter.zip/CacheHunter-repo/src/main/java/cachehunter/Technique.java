package cachehunter;

/**
 * A single, documented technique/payload extracted from the research corpus.
 * Used both by the scanning engine and the read-only "Techniques DB" viewer.
 */
public class Technique {

    public enum Kind {
        UNKEYED_HEADER,   // inject canary in a request header (host/scheme/url/method-override ...)
        UNKEYED_COOKIE,   // inject canary in a cookie parameter
        FAT_GET,          // body param overriding url param
        PARAM_CLOAKING,   // parser discrepancy in query parsing
        UNKEYED_PARAM,    // param excluded from cache key
        DOS,              // CPDoS - cacheable error primitive
        DECEPTION_PATH    // path/extension/delimiter/normalization suffix for cache deception
    }

    public final Kind kind;
    public final String category;   // human group, e.g. "Host spoofing"
    public final String name;       // e.g. "X-Forwarded-Host"
    public final String payload;    // template / example payload
    public final String description;// what it does
    public final String source;     // where it came from in the corpus

    public Technique(Kind kind, String category, String name, String payload, String description, String source) {
        this.kind = kind;
        this.category = category;
        this.name = name;
        this.payload = payload;
        this.description = description;
        this.source = source;
    }
}
