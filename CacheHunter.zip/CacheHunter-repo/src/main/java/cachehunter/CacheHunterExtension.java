package cachehunter;

import burp.api.montoya.BurpExtension;
import burp.api.montoya.MontoyaApi;

/**
 * Entry point. Burp discovers this class (it implements {@link BurpExtension}) and calls
 * {@link #initialize(MontoyaApi)}. We build the shared config, engine and UI, and register the
 * single "Cache Hunter" suite tab.
 */
public class CacheHunterExtension implements BurpExtension {

    @Override
    public void initialize(MontoyaApi api) {
        api.extension().setName("Cache Hunter — WCP/WCD real-time scanner");

        Logger log = new Logger(api);
        ScanConfig cfg = new ScanConfig();
        RateLimiter limiter = new RateLimiter(cfg);
        ScanEngine engine = new ScanEngine(api, cfg, log, limiter);

        CacheHunterTab tab = new CacheHunterTab(api, cfg, engine, log);
        api.userInterface().registerSuiteTab("Cache Hunter", tab);
        try { api.userInterface().applyThemeToComponent(tab); } catch (Exception ignored) {}

        api.extension().registerUnloadingHandler(() -> {
            engine.shutdown();
            tab.dispose();
        });

        log.info("Cache Hunter loaded. " + TechniqueLibrary.catalogue().size()
                + " techniques ready. Set scope, press Start, and browse (or Import History / Site Map).");
        log.info("Reminder: only test systems you are authorised to test. PoCs use a cache-buster to stay safe.");
    }
}
