package cachehunter;

import burp.api.montoya.MontoyaApi;
import burp.api.montoya.http.message.HttpHeader;
import burp.api.montoya.http.message.HttpRequestResponse;
import burp.api.montoya.http.message.requests.HttpRequest;
import burp.api.montoya.http.message.responses.HttpResponse;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Generates probe requests for every technique in {@link TechniqueLibrary} and runs the
 * detection oracles for web cache poisoning, web cache deception and cache-poisoning DoS.
 * Findings and every request sent are streamed back to the module UI via {@link ModuleSink}.
 */
class Scanners {

    private final MontoyaApi api;
    private final ScanConfig cfg;
    private final Logger log;
    private final Sender sender;

    Scanners(MontoyaApi api, ScanConfig cfg, Logger log, Sender sender) {
        this.api = api;
        this.cfg = cfg;
        this.log = log;
        this.sender = sender;
    }

    // ==========================================================================================
    //  WEB CACHE POISONING
    // ==========================================================================================
    void scanPoison(HttpRequestResponse base, int parentId, ModuleSink sink) {
        HttpRequest req = base.request();
        HttpResponse baseResp = base.response();
        int baseStatus = baseResp != null ? baseResp.statusCode() : 200;

        // ---- 1. Host / URL-override header reflection ----
        List<String> headers = new ArrayList<>();
        headers.addAll(TechniqueLibrary.HOST_HEADERS);
        headers.addAll(TechniqueLibrary.URL_OVERRIDE_HEADERS);
        for (String h : headers) {
            if (cfg.isStopped()) return;
            String token = rnd();
            boolean urlOverride = TechniqueLibrary.URL_OVERRIDE_HEADERS.contains(h);
            String value = urlOverride ? "/" + token : token + "." + cfg.attackerDomain();
            String target = addBuster(req.path());
            HttpRequest probe = req.withPath(target).withUpdatedHeader(h, value);
            HttpRequestResponse rr = sender.send(probe);
            HttpResponse rs = rr != null ? rr.response() : null;
            boolean reflected = respContainsToken(rs, token);
            sink.addTest(testRow(sink, parentId, "Unkeyed header: " + h, h, rr, reflected,
                    reflected ? "reflected" : ""));
            if (!reflected) continue;

            String ctx = reflectionContext(rs, token);
            // confirm poisoning: fetch same URL+buster WITHOUT our header
            HttpRequestResponse crr = sender.send(req.withPath(target));
            HttpResponse cres = crr != null ? crr.response() : null;
            boolean persisted = respContainsToken(cres, token);
            sink.addTest(testRow(sink, parentId, "Confirm poison: " + h, h, crr, persisted,
                    persisted ? "cached/persisted" : "not persisted"));

            boolean dangerous = isDangerousContext(ctx);
            boolean cacheable = CacheAnalyzer.isCacheable(rs) || CacheAnalyzer.isCacheHit(cres);
            Finding.Severity sev;
            if (persisted && dangerous) sev = Finding.Severity.CRITICAL;
            else if (persisted)         sev = Finding.Severity.HIGH;
            else if (cacheable && dangerous) sev = Finding.Severity.HIGH;
            else if (cacheable)         sev = Finding.Severity.MEDIUM;
            else                        sev = Finding.Severity.LOW;

            String vary = rs != null ? CacheAnalyzer.headerValue(rs, "Vary") : null;
            String ev = "value reflected in " + ctx + (persisted ? "; persisted after removing header" : "")
                    + (cacheable ? "; response cacheable" : "")
                    + (vary != null ? "; Vary: " + vary + " (target victims with this header value)" : "");
            addFinding(sink, sev, "Unkeyed header " + h, req, h, ev, CacheAnalyzer.label(rs), rr, crr);
            log.good(sink.moduleName() + ": " + sev + " unkeyed header " + h + " on " + hostOf(req));
        }

        // ---- 2. Scheme-header open-redirect combos ----
        for (String sh : TechniqueLibrary.SCHEME_HEADERS) {
            if (cfg.isStopped()) return;
            String token = rnd();
            String canary = token + "." + cfg.attackerDomain();
            String target = addBuster(req.path());
            HttpRequest probe = req.withPath(target)
                    .withUpdatedHeader("X-Forwarded-Host", canary)
                    .withUpdatedHeader(sh, "nothttps");
            HttpRequestResponse rr = sender.send(probe);
            HttpResponse rs = rr != null ? rr.response() : null;
            String loc = rs != null ? CacheAnalyzer.headerValue(rs, "Location") : null;
            boolean inLoc = loc != null && loc.toLowerCase(Locale.ROOT).contains(token);
            sink.addTest(testRow(sink, parentId, "Scheme combo: " + sh, "X-Forwarded-Host+" + sh, rr, inLoc,
                    inLoc ? "Location -> " + loc : ""));
            if (inLoc) {
                HttpRequestResponse crr = sender.send(req.withPath(target));
                HttpResponse cres = crr != null ? crr.response() : null;
                String cloc = cres != null ? CacheAnalyzer.headerValue(cres, "Location") : null;
                boolean persisted = cloc != null && cloc.toLowerCase(Locale.ROOT).contains(token);
                sink.addTest(testRow(sink, parentId, "Confirm redirect: " + sh, sh, crr, persisted,
                        persisted ? "cached redirect" : ""));
                Finding.Severity sev = persisted ? Finding.Severity.HIGH : Finding.Severity.MEDIUM;
                addFinding(sink, sev, "Cacheable open redirect (" + sh + ")", req, "X-Forwarded-Host+" + sh,
                        "redirect Location controllable -> " + loc, CacheAnalyzer.label(rs), rr, crr);
                log.good(sink.moduleName() + ": " + sev + " cacheable open redirect via " + sh);
            }
        }

        // ---- 3. Cookie reflection ----
        String existingCookie = headerValue(req, "Cookie");
        for (String c : TechniqueLibrary.COOKIE_PARAMS) {
            if (cfg.isStopped()) return;
            String token = rnd();
            String cookieVal = c + "=" + token;
            String newCookie = existingCookie == null || existingCookie.isBlank()
                    ? cookieVal : existingCookie + "; " + cookieVal;
            String target = addBuster(req.path());
            HttpRequest probe = req.withPath(target).withUpdatedHeader("Cookie", newCookie);
            HttpRequestResponse rr = sender.send(probe);
            HttpResponse rs = rr != null ? rr.response() : null;
            boolean reflected = respContainsToken(rs, token);
            sink.addTest(testRow(sink, parentId, "Unkeyed cookie: " + c, "Cookie:" + c, rr, reflected,
                    reflected ? "reflected" : ""));
            if (!reflected) continue;
            String ctx = reflectionContext(rs, token);
            HttpRequestResponse crr = sender.send(req.withPath(target));
            boolean persisted = respContainsToken(crr != null ? crr.response() : null, token);
            sink.addTest(testRow(sink, parentId, "Confirm cookie poison: " + c, "Cookie:" + c, crr, persisted,
                    persisted ? "persisted" : ""));
            boolean cacheable = CacheAnalyzer.isCacheable(rs);
            Finding.Severity sev = persisted ? Finding.Severity.HIGH
                    : (cacheable ? Finding.Severity.MEDIUM : Finding.Severity.LOW);
            addFinding(sink, sev, "Unkeyed cookie " + c, req, "Cookie:" + c,
                    "cookie reflected in " + ctx, CacheAnalyzer.label(rs), rr, crr);
        }

        // ---- 4. Fat GET ----
        if (!cfg.isStopped()) {
            String token = rnd();
            String pname = firstQueryParam(req);
            if (pname == null) pname = "utm_content";
            String target = addBuster(req.path());
            HttpRequest probe = req.withPath(target).withMethod("GET")
                    .withUpdatedHeader("Content-Type", "application/x-www-form-urlencoded")
                    .withBody(pname + "=" + token);
            HttpRequestResponse rr = sender.send(probe);
            HttpResponse rs = rr != null ? rr.response() : null;
            boolean reflected = respContainsToken(rs, token);
            sink.addTest(testRow(sink, parentId, "Fat GET (body param " + pname + ")", "body:" + pname, rr,
                    reflected, reflected ? "body param used" : ""));
            if (reflected) {
                boolean cacheable = CacheAnalyzer.isCacheable(rs);
                addFinding(sink, cacheable ? Finding.Severity.HIGH : Finding.Severity.MEDIUM,
                        "Fat GET request", req, "body:" + pname,
                        "body parameter influenced a cacheable GET response", CacheAnalyzer.label(rs), rr, null);
            }
        }

        // ---- 5. Parameter cloaking ----
        if (!cfg.isStopped()) {
            String bp = pathNoQuery(req);
            String t1 = rnd(), t2 = rnd();
            String[][] cloaks = {
                    {bp + "?x=" + t1 + "?cbust=" + rnd(), "dup-? cloaking"},
                    {bp + "?cbust=" + rnd() + "&utm_content=1;x=" + t2, "semicolon cloaking"}
            };
            for (String[] cl : cloaks) {
                if (cfg.isStopped()) return;
                HttpRequestResponse rr = sender.send(req.withPath(cl[0]));
                HttpResponse rs = rr != null ? rr.response() : null;
                String tok = cl[1].startsWith("dup") ? t1 : t2;
                boolean reflected = respContainsToken(rs, tok);
                sink.addTest(testRow(sink, parentId, "Param cloaking: " + cl[1], "query", rr, reflected,
                        reflected ? "cloaked param used" : ""));
                if (reflected && CacheAnalyzer.isCacheable(rs)) {
                    addFinding(sink, Finding.Severity.MEDIUM, "Parameter cloaking (" + cl[1] + ")", req, "query",
                            "cloaked parameter reached the app while cacheable", CacheAnalyzer.label(rs), rr, null);
                }
            }
        }

        // ---- 6. Unkeyed query parameters (ALL of them - no cap) ----
        for (String p : TechniqueLibrary.UNKEYED_QUERY_PARAMS) {
            if (cfg.isStopped()) return;
            String token = rnd();
            String target = addBuster(pathNoQuery(req) + "?" + p + "=" + token);
            HttpRequestResponse rr = sender.send(req.withPath(target));
            HttpResponse rs = rr != null ? rr.response() : null;
            boolean reflected = respContainsToken(rs, token);
            sink.addTest(testRow(sink, parentId, "Unkeyed param: " + p, "param:" + p, rr, reflected,
                    reflected ? "reflected" : ""));
            if (reflected && CacheAnalyzer.isCacheable(rs)) {
                addFinding(sink, Finding.Severity.MEDIUM, "Unkeyed query parameter " + p, req, "param:" + p,
                        "parameter reflected in a cacheable response", CacheAnalyzer.label(rs), rr, null);
            }
        }

        // ---- 6b. Cache-key injection, port-XSS, cache-key oracle, PURGE ----
        scanKeyAndMisc(req, parentId, sink);

        // ---- 7. Cache-poisoning DoS (CPDoS) ----
        if (cfg.probeDos()) scanDos(req, baseStatus, parentId, sink);
    }

    /**
     * Additional poisoning primitives from the corpus that need bespoke oracles:
     *  - X-Forwarded-Port non-numeric  -> reflected XSS in a generated URL
     *  - Host header with unkeyed port -> port reflected in Location while cache ignores it
     *  - Cache-key oracle (Akamai Pragma) -> reveals the exact cache key
     *  - PURGE method honoured          -> cache-flush / re-poisoning primitive
     *  - URL-encoded duplicate key param -> cache-key injection (siz%65 style)
     */
    private void scanKeyAndMisc(HttpRequest req, int parentId, ModuleSink sink) {
        // (a) X-Forwarded-Port non-numeric -> XSS in generated URL
        for (String ph : TechniqueLibrary.PORT_HEADERS) {
            if (cfg.isStopped()) return;
            String token = rnd();
            String xss = "8443\"><svg-" + token + ">";
            String target = addBuster(req.path());
            HttpRequestResponse rr = sender.send(req.withPath(target).withUpdatedHeader(ph, xss));
            HttpResponse rs = rr != null ? rr.response() : null;
            boolean reflected = respContainsToken(rs, token);
            sink.addTest(testRow(sink, parentId, "Port XSS: " + ph, ph, rr, reflected,
                    reflected ? "reflected in " + reflectionContext(rs, token) : ""));
            if (reflected) {
                HttpRequestResponse crr = sender.send(req.withPath(target));
                boolean persisted = respContainsToken(crr != null ? crr.response() : null, token);
                addFinding(sink, persisted ? Finding.Severity.HIGH : Finding.Severity.MEDIUM,
                        "Non-numeric port injection (" + ph + ")", req, ph,
                        "port header reflected in " + reflectionContext(rs, token), CacheAnalyzer.label(rs), rr, crr);
            }
        }

        // (b) Host header with unkeyed port (Host: host:31337) -> port reflected but key ignores it
        if (!cfg.isStopped()) {
            String host = hostOf(req);
            String target = addBuster(req.path());
            HttpRequest probe = req.withPath(target).withUpdatedHeader("Host", host + ":31337");
            HttpRequestResponse rr = sender.send(probe);
            HttpResponse rs = rr != null ? rr.response() : null;
            String loc = rs != null ? CacheAnalyzer.headerValue(rs, "Location") : null;
            boolean portReflected = (loc != null && loc.contains(":31337"))
                    || (rs != null && rs.bodyToString() != null && rs.bodyToString().contains(":31337"));
            sink.addTest(testRow(sink, parentId, "Unkeyed port (Host:31337)", "Host:port", rr, portReflected,
                    portReflected ? (loc != null ? "Location " + loc : "reflected") : ""));
            if (portReflected) {
                HttpRequestResponse crr = sender.send(req.withPath(target));
                HttpResponse cres = crr != null ? crr.response() : null;
                String cloc = cres != null ? CacheAnalyzer.headerValue(cres, "Location") : null;
                boolean cached = (cloc != null && cloc.contains(":31337"))
                        || (cres != null && cres.bodyToString() != null && cres.bodyToString().contains(":31337"));
                addFinding(sink, cached ? Finding.Severity.HIGH : Finding.Severity.MEDIUM,
                        "Unkeyed port in Host header", req, "Host:port",
                        "arbitrary port reflected in generated URL while cache key ignores the port"
                                + (cached ? " (cached - DoS/redirect)" : ""), CacheAnalyzer.label(rs), rr, crr);
            }
        }

        // (c) Cache-key oracle (Akamai) -> reveal the exact cache key (INFO, aids exploitation)
        for (String pragma : TechniqueLibrary.CACHE_KEY_ORACLE_PRAGMAS) {
            if (cfg.isStopped()) return;
            String target = addBuster(req.path());
            HttpRequestResponse rr = sender.send(req.withPath(target).withUpdatedHeader("Pragma", pragma));
            HttpResponse rs = rr != null ? rr.response() : null;
            String ck = rs != null ? CacheAnalyzer.headerValue(rs, "X-Cache-Key") : null;
            if (ck == null && rs != null) ck = CacheAnalyzer.headerValue(rs, "X-Check-Cacheable");
            boolean got = ck != null;
            sink.addTest(testRow(sink, parentId, "Cache-key oracle: " + pragma, "Pragma", rr, got,
                    got ? ("X-Cache-Key: " + ck) : ""));
            if (got) {
                addFinding(sink, Finding.Severity.INFO, "Cache-key oracle exposed (Akamai)", req, "Pragma: " + pragma,
                        "cache key revealed: " + ck, CacheAnalyzer.label(rs), rr, null);
                break;   // one oracle is enough
            }
        }

        // (d) PURGE method honoured -> cache flush / re-poisoning primitive (DESTRUCTIVE - opt-in only)
        if (!cfg.isStopped() && cfg.enablePurge()) {
            String target = addBuster(req.path());
            HttpRequestResponse rr = sender.send(req.withPath(target).withMethod("PURGE"));
            HttpResponse rs = rr != null ? rr.response() : null;
            int sc = rs != null ? rs.statusCode() : -1;
            String body = rs != null && rs.bodyToString() != null ? rs.bodyToString().toLowerCase(Locale.ROOT) : "";
            boolean honoured = (sc == 200 || sc == 201 || sc == 202 || sc == 204)
                    || body.contains("purge") || body.contains("flushed") || body.contains("ok");
            sink.addTest(testRow(sink, parentId, "PURGE method probe", "method:PURGE", rr, false,
                    sc >= 0 ? ("status " + sc) : ""));
            if (honoured && sc >= 0 && sc < 400) {
                addFinding(sink, Finding.Severity.LOW, "Cache PURGE method honoured", req, "method:PURGE",
                        "server accepted PURGE (status " + sc + ") - enables on-demand cache flush / re-poisoning",
                        CacheAnalyzer.label(rs), rr, null);
            }
        }

        // (e) URL-encoded duplicate keyed param -> cache-key injection (siz%65 style)
        String firstParam = firstQueryParam(req);
        if (!cfg.isStopped() && firstParam != null && firstParam.length() >= 2) {
            String enc = firstParam.substring(0, firstParam.length() - 1)
                    + "%" + String.format("%02x", (int) firstParam.charAt(firstParam.length() - 1));
            String target = addBuster(req.path() + "&" + enc + "=0");
            HttpRequestResponse rr = sender.send(req.withPath(target));
            HttpResponse rs = rr != null ? rr.response() : null;
            boolean cacheableError = rs != null && rs.statusCode() >= 400 && rs.statusCode() < 500
                    && CacheAnalyzer.isCacheable(rs);
            sink.addTest(testRow(sink, parentId, "Cache-key injection (encoded dup param)", "param:" + enc, rr, false,
                    rs != null ? ("status " + rs.statusCode()) : ""));
            if (cacheableError) {
                addFinding(sink, Finding.Severity.MEDIUM, "Cache-key injection via encoded parameter", req,
                        "param:" + enc, "URL-encoded duplicate of keyed param '" + firstParam
                                + "' produced a cacheable " + rs.statusCode(), CacheAnalyzer.label(rs), rr, null);
            }
        }
    }

    private void scanDos(HttpRequest req, int baseStatus, int parentId, ModuleSink sink) {
        // ---- method-override headers: GET->HEAD yields empty cacheable body (GitLab static DoS) ----
        for (String mh : TechniqueLibrary.METHOD_OVERRIDE_HEADERS) {
            if (cfg.isStopped()) return;
            String target = addBuster(req.path());
            HttpRequest probe = req.withPath(target).withUpdatedHeader(mh, "HEAD");
            HttpRequestResponse rr = sender.send(probe);
            HttpResponse rs = rr != null ? rr.response() : null;
            boolean bad = isBadOrEmpty(rs, baseStatus, mh);
            sink.addTest(testRow(sink, parentId, "CPDoS: " + mh + ": HEAD", mh, rr, false,
                    rs != null ? ("status " + rs.statusCode()) : ""));
            if (!bad) continue;
            HttpRequestResponse crr = sender.send(req.withPath(target));
            boolean cachedBad = isBadOrEmpty(crr != null ? crr.response() : null, baseStatus, mh);
            sink.addTest(testRow(sink, parentId, "Confirm CPDoS: " + mh, mh, crr, false,
                    cachedBad ? "empty/error cached" : "not cached"));
            addFinding(sink, cachedBad ? Finding.Severity.HIGH : Finding.Severity.MEDIUM,
                    "CPDoS via method override (" + mh + ")", req, mh,
                    "override GET->HEAD produced empty/altered cacheable response", CacheAnalyzer.label(rs), rr, crr);
            if (cachedBad) log.good(sink.moduleName() + ": HIGH CPDoS via " + mh + " on " + hostOf(req));
        }
        // ---- X-Forwarded-Port with a dud numeric port -> timeout/redirect to dead port ----
        for (String ph : TechniqueLibrary.PORT_HEADERS) {
            if (cfg.isStopped()) return;
            String target = addBuster(req.path());
            HttpRequest probe = req.withPath(target).withUpdatedHeader(ph, "1");
            HttpRequestResponse rr = sender.send(probe);
            HttpResponse rs = rr != null ? rr.response() : null;
            String loc = rs != null ? CacheAnalyzer.headerValue(rs, "Location") : null;
            boolean dudPort = (loc != null && loc.contains(":1/")) || isBadOrEmpty(rs, baseStatus, ph);
            sink.addTest(testRow(sink, parentId, "CPDoS: " + ph + ": 1", ph, rr, false,
                    rs != null ? ("status " + rs.statusCode() + (loc != null ? " Location " + loc : "")) : ""));
            if (!dudPort) continue;
            HttpRequestResponse crr = sender.send(req.withPath(target));
            HttpResponse cres = crr != null ? crr.response() : null;
            String cloc = cres != null ? CacheAnalyzer.headerValue(cres, "Location") : null;
            boolean cached = (cloc != null && cloc.contains(":1/")) || isBadOrEmpty(cres, baseStatus, ph);
            sink.addTest(testRow(sink, parentId, "Confirm CPDoS: " + ph, ph, crr, false,
                    cached ? "dud-port response cached" : "not cached"));
            addFinding(sink, cached ? Finding.Severity.HIGH : Finding.Severity.MEDIUM,
                    "CPDoS via " + ph + " (dud port)", req, ph,
                    "invalid port poisoned redirect/response" + (loc != null ? " -> " + loc : ""),
                    CacheAnalyzer.label(rs), rr, crr);
        }
        // header primitives
        for (String[] prim : TechniqueLibrary.DOS_HEADER_PRIMITIVES) {
            if (cfg.isStopped()) return;
            String target = addBuster(req.path());
            HttpRequest probe = req.withPath(target).withUpdatedHeader(prim[0], prim[1]);
            HttpRequestResponse rr = sender.send(probe);
            HttpResponse rs = rr != null ? rr.response() : null;
            boolean bad = isBadOrEmpty(rs, baseStatus, prim[0]);
            sink.addTest(testRow(sink, parentId, "CPDoS: " + prim[0] + ": " + prim[1], prim[0], rr, false,
                    rs != null ? ("status " + rs.statusCode()) : ""));
            if (!bad) continue;
            HttpRequestResponse crr = sender.send(req.withPath(target));
            HttpResponse cres = crr != null ? crr.response() : null;
            boolean cachedBad = isBadOrEmpty(cres, baseStatus, prim[0]);
            sink.addTest(testRow(sink, parentId, "Confirm CPDoS: " + prim[0], prim[0], crr, false,
                    cachedBad ? "error cached" : "not cached"));
            boolean cacheable = CacheAnalyzer.isCacheable(rs);
            Finding.Severity sev = cachedBad ? Finding.Severity.HIGH
                    : (cacheable ? Finding.Severity.MEDIUM : Finding.Severity.LOW);
            addFinding(sink, sev, "Cache-poisoning DoS via " + prim[0], req, prim[0],
                    "primitive '" + prim[0] + ": " + prim[1] + "' -> " + (rs != null ? rs.statusCode() : "?")
                            + (cachedBad ? " (cached)" : ""), CacheAnalyzer.label(rs), rr, crr);
            if (cachedBad) log.good(sink.moduleName() + ": HIGH CPDoS via " + prim[0] + " on " + hostOf(req));
        }
        // HHO - oversized header
        if (!cfg.isStopped()) {
            String target = addBuster(req.path());
            HttpRequest probe = req.withPath(target)
                    .withUpdatedHeader("X-Oversize", "A".repeat(TechniqueLibrary.HHO_HEADER_SIZE));
            HttpRequestResponse rr = sender.send(probe);
            HttpResponse rs = rr != null ? rr.response() : null;
            boolean bad = isBadOrEmpty(rs, baseStatus, "X-Oversize");
            sink.addTest(testRow(sink, parentId, "CPDoS: HHO oversized header", "X-Oversize", rr, false,
                    rs != null ? ("status " + rs.statusCode()) : ""));
            if (bad) {
                HttpRequestResponse crr = sender.send(req.withPath(target));
                boolean cachedBad = isBadOrEmpty(crr != null ? crr.response() : null, baseStatus, "X-Oversize");
                addFinding(sink, cachedBad ? Finding.Severity.HIGH : Finding.Severity.MEDIUM,
                        "CPDoS via oversized header (HHO)", req, "X-Oversize",
                        "oversized header -> " + (rs != null ? rs.statusCode() : "?"), CacheAnalyzer.label(rs), rr, crr);
            }
        }
        // query primitives
        for (String q : TechniqueLibrary.DOS_QUERY_PRIMITIVES) {
            if (cfg.isStopped()) return;
            String target = addBuster(pathNoQuery(req) + "?" + q.replace("{RND}", "j" + rnd()));
            HttpRequestResponse rr = sender.send(req.withPath(target));
            HttpResponse rs = rr != null ? rr.response() : null;
            boolean bad = isBadOrEmpty(rs, baseStatus, "query");
            sink.addTest(testRow(sink, parentId, "CPDoS: query primitive", "query", rr, false,
                    rs != null ? ("status " + rs.statusCode()) : ""));
            if (bad) {
                HttpRequestResponse crr = sender.send(req.withPath(target));
                boolean cachedBad = isBadOrEmpty(crr != null ? crr.response() : null, baseStatus, "query");
                addFinding(sink, cachedBad ? Finding.Severity.HIGH : Finding.Severity.MEDIUM,
                        "CPDoS via malformed query", req, "query",
                        "malformed query -> " + (rs != null ? rs.statusCode() : "?"), CacheAnalyzer.label(rs), rr, crr);
            }
        }
    }

    // ==========================================================================================
    //  WEB CACHE DECEPTION
    // ==========================================================================================
    void scanDeception(HttpRequestResponse base, int parentId, ModuleSink sink) {
        HttpRequest req = base.request();
        HttpResponse baseResp = base.response();
        if (baseResp == null) return;
        String baseBody = baseResp.bodyToString();
        if (baseBody == null || baseBody.isEmpty()) return;
        int baseStatus = baseResp.statusCode();
        if (baseStatus != 200) return;                       // need a normal dynamic page
        boolean baseCacheable = CacheAnalyzer.isCacheable(baseResp);
        Set<String> baseMarkers = markersIn(baseBody);

        String basePath = pathNoQuery(req);
        if (basePath.isEmpty()) basePath = "/";

        List<String> exts = priorityExts();
        List<String[]> variants = buildDeceptionVariants(basePath, exts);   // {target, techniqueLabel}

        for (String[] v : variants) {
            if (cfg.isStopped()) return;
            String target = addBuster(v[0]);
            HttpRequest probe = req.withPath(target);
            HttpRequestResponse rr = sender.send(probe);
            HttpResponse rs = rr != null ? rr.response() : null;
            String note = rs != null ? ("status " + rs.statusCode() + ", cache " + CacheAnalyzer.label(rs)) : "";
            sink.addTest(testRow(sink, parentId, "Deception: " + v[1], "path", rr, false, note));
            if (rs == null || rs.statusCode() != 200) continue;

            boolean originIgnored = bodySimilar(baseBody, rs.bodyToString());
            if (!originIgnored) continue;
            boolean cacheable = CacheAnalyzer.isCacheable(rs) || CacheAnalyzer.isCacheHit(rs);
            if (!cacheable) continue;

            // confirm anonymously: same URL, drop ALL auth material (cookie + common auth headers)
            HttpRequest confReq = stripAuth(probe);
            HttpRequestResponse crr = sender.send(confReq);
            HttpResponse cres = crr != null ? crr.response() : null;
            boolean leaked = cres != null && bodySimilar(baseBody, cres.bodyToString())
                    && !markersIn(cres.bodyToString()).isEmpty();
            boolean confirmedHit = cres != null && CacheAnalyzer.isCacheHit(cres);
            sink.addTest(testRow(sink, parentId, "Confirm deception (anon): " + v[1], "path", crr, false,
                    leaked ? "anon retrieved private content" : (confirmedHit ? "cache HIT" : "not confirmed")));

            Finding.Severity sev = leaked ? Finding.Severity.CRITICAL
                    : ((confirmedHit || CacheAnalyzer.isCacheHit(rs)) ? Finding.Severity.HIGH : Finding.Severity.MEDIUM);
            StringBuilder ev = new StringBuilder("origin served base content with static suffix; ")
                    .append(cacheable ? "response cacheable" : "");
            if (!baseCacheable) ev.append("; base was NOT cacheable");
            if (!baseMarkers.isEmpty()) ev.append("; sensitive markers: ").append(String.join(",", baseMarkers));
            if (leaked) ev.append("; anonymous request retrieved the private response");
            addFinding(sink, sev, "Web cache deception (" + v[1] + ")", req, v[0], ev.toString(),
                    CacheAnalyzer.label(rs), rr, crr);
            log.good(sink.moduleName() + ": " + sev + " deception " + v[1] + " on " + hostOf(req));
        }
    }

    /** Build a bounded, de-duplicated list of deception URL variants from the live technique lists. */
    private List<String[]> buildDeceptionVariants(String basePath, List<String> exts) {
        Set<String> seen = new LinkedHashSet<>();
        List<String[]> out = new ArrayList<>();
        List<String> delims = cfg.snapshotDelimiters();
        int max = 500;   // safety valve is the global Request-limit; this only bounds per-endpoint fan-out

        // delimiter/extension templates - apply EVERY priority extension to EVERY template
        for (int di = 0; di < delims.size() && out.size() < max; di++) {
            String tmpl = delims.get(di);
            List<String> useExts = exts;   // full breadth on all templates
            for (String ext : useExts) {
                if (out.size() >= max) break;
                String target = tmpl
                        .replace("{B}", basePath)
                        .replace("{EXT}", ext)
                        .replace("{RND}", "wcd" + rnd());
                target = collapseSlashes(target);
                if (seen.add(target)) out.add(new String[]{target, "delimiter " + tmpl + " ." + ext});
            }
        }
        // normalization/traversal templates
        List<String> dirs = cfg.snapshotDirs();
        List<String> normTmpls = TechniqueLibrary.DECEPTION_NORMALIZATION;
        for (String tmpl : normTmpls) {
            if (out.size() >= max) break;
            int dirCount = 0;
            for (String dir : dirs) {
                if (dirCount++ >= 4 || out.size() >= max) break;
                for (String ext : List.of("js", "css")) {
                    if (out.size() >= max) break;
                    String target = tmpl
                            .replace("{B}", basePath.startsWith("/") ? basePath.substring(1) : basePath)
                            .replace("{DIR}", dir)
                            .replace("{EXT}", ext)
                            .replace("{RND}", "wcd" + rnd());
                    if (!target.startsWith("/")) target = "/" + target;
                    if (seen.add(target)) out.add(new String[]{target, "normalization " + tmpl});
                }
            }
        }
        return out;
    }

    // ==========================================================================================
    //  Detection helpers
    // ==========================================================================================
    private static boolean isBadOrEmpty(HttpResponse rs, int baseStatus, String primitive) {
        if (rs == null) return false;
        int sc = rs.statusCode();
        boolean errorStatus = (sc == 400 || sc == 403 || sc == 405 || sc == 406 || sc == 411
                || sc == 413 || sc == 414 || sc == 416 || sc == 431 || sc == 500 || sc == 501
                || sc == 502 || sc == 503);
        if (errorStatus && baseStatus < 400) return true;
        // method-override HEAD -> empty body 200
        if (sc == 200) {
            String body = rs.bodyToString();
            if (body != null && body.isEmpty()) return true;
        }
        return false;
    }

    /** True if the token appears in the response body or any response header (case-insensitive). */
    private static boolean respContainsToken(HttpResponse rs, String token) {
        if (rs == null) return false;
        String needle = token.toLowerCase(Locale.ROOT);
        String body = capBody(rs.bodyToString());
        if (body != null && body.toLowerCase(Locale.ROOT).contains(needle)) return true;
        for (HttpHeader h : rs.headers()) {
            if (h.value() != null && h.value().toLowerCase(Locale.ROOT).contains(needle)) return true;
        }
        return false;
    }

    /** Where the token landed - determines XSS/redirect potential. */
    private static String reflectionContext(HttpResponse rs, String token) {
        if (rs == null) return "body";
        String loc = CacheAnalyzer.headerValue(rs, "Location");
        if (loc != null && loc.toLowerCase(Locale.ROOT).contains(token.toLowerCase(Locale.ROOT)))
            return "Location redirect";
        String body = capBody(rs.bodyToString());
        if (body == null) return "header";
        String lb = body.toLowerCase(Locale.ROOT);
        int i = lb.indexOf(token.toLowerCase(Locale.ROOT));
        if (i < 0) return "header";
        int from = Math.max(0, i - 40);
        String win = lb.substring(from, Math.min(lb.length(), i + token.length() + 10));
        if (win.contains("<script")) return "script tag";
        if (win.contains("src=")) return "src attribute";
        if (win.contains("href=")) return "href attribute";
        if (win.contains("content=")) return "meta content";
        if (win.contains("action=")) return "form action";
        if (win.contains("url(")) return "css url()";
        return "body";
    }

    private static boolean isDangerousContext(String ctx) {
        return ctx.equals("script tag") || ctx.equals("src attribute") || ctx.equals("href attribute")
                || ctx.equals("meta content") || ctx.equals("form action") || ctx.equals("css url()")
                || ctx.equals("Location redirect");
    }

    /** Heuristic body-equivalence: same length band and/or shared sensitive markers. */
    private boolean bodySimilar(String a, String b) {
        if (a == null || b == null) return false;
        int la = a.length(), lb = b.length();
        if (la == 0 || lb == 0) return false;
        boolean within = Math.abs(la - lb) <= Math.max(64, (long) (la * 0.10));
        if (within) return true;
        Set<String> ma = markersIn(a);
        Set<String> mb = markersIn(b);
        if (!ma.isEmpty()) {
            for (String m : ma) if (mb.contains(m)) {
                return Math.abs(la - lb) <= la * 0.5; // shared secret + roughly same size
            }
        }
        return false;
    }

    private Set<String> markersIn(String body) {
        Set<String> found = new LinkedHashSet<>();
        if (body == null) return found;
        String lb = capBody(body).toLowerCase(Locale.ROOT);
        for (String m : cfg.snapshotMarkers()) {
            if (lb.contains(m.toLowerCase(Locale.ROOT))) found.add(m);
        }
        return found;
    }

    private List<String> priorityExts() {
        List<String> live = cfg.snapshotExtensions();
        List<String> out = new ArrayList<>();
        for (String e : TechniqueLibrary.PRIORITY_EXTENSIONS) if (live.contains(e)) out.add(e);
        if (out.isEmpty()) out.addAll(List.of("js", "css"));
        return out;
    }

    // ==========================================================================================
    //  Request-building helpers
    // ==========================================================================================
    private static String addBuster(String target) {
        String sep = target.contains("?") ? "&" : "?";
        return target + sep + "cchz" + rnd() + "=" + rnd();
    }

    /** Common request headers that carry authentication - removed to make a truly anonymous request. */
    private static final String[] AUTH_HEADERS = {
            "Cookie", "Authorization", "Proxy-Authorization",
            "X-Auth-Token", "X-Access-Token", "X-Api-Key", "Api-Key", "Apikey",
            "X-Session-Token", "X-Session-Id", "X-Csrf-Token", "X-Xsrf-Token",
            "Auth-Token", "X-Auth", "X-Amz-Security-Token", "X-Sf-Auth", "Bearer",
            "X-User-Token", "X-Access-Key", "X-Secret", "Token"
    };

    private static HttpRequest stripAuth(HttpRequest req) {
        HttpRequest out = req;
        for (String h : AUTH_HEADERS) out = out.withRemovedHeader(h);
        return out;
    }

    /** Cap a body before expensive lowercase/contains scans (protects against huge/binary bodies). */
    private static String capBody(String s) {
        if (s == null) return null;
        return s.length() > ScanConfig.MAX_BODY_SCAN ? s.substring(0, ScanConfig.MAX_BODY_SCAN) : s;
    }

    private static String pathNoQuery(HttpRequest req) {
        String p = req.pathWithoutQuery();
        return p == null ? "/" : p;
    }

    private static String firstQueryParam(HttpRequest req) {
        String q = req.query();
        if (q == null || q.isBlank()) return null;
        String first = q.split("&", 2)[0];
        int eq = first.indexOf('=');
        String name = eq > 0 ? first.substring(0, eq) : first;
        return name.isBlank() ? null : name;
    }

    private static String headerValue(HttpRequest req, String name) {
        for (HttpHeader h : req.headers()) if (h.name().equalsIgnoreCase(name)) return h.value();
        return null;
    }

    private static String hostOf(HttpRequest req) {
        try { return req.httpService().host(); } catch (Exception e) { return "?"; }
    }

    private static String collapseSlashes(String target) {
        // collapse only literal double slashes in the path portion (keep %2f etc. intact)
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < target.length(); i++) {
            char c = target.charAt(i);
            if (c == '/' && sb.length() > 0 && sb.charAt(sb.length() - 1) == '/') continue;
            sb.append(c);
        }
        return sb.toString();
    }

    private static String rnd() {
        final String cs = "abcdefghijklmnopqrstuvwxyz0123456789";
        StringBuilder sb = new StringBuilder(8);
        for (int i = 0; i < 8; i++) sb.append(cs.charAt(ThreadLocalRandom.current().nextInt(cs.length())));
        return sb.toString();
    }

    // ==========================================================================================
    //  UI row / finding helpers
    // ==========================================================================================
    private static HistoryEntry testRow(ModuleSink sink, int parentId, String technique, String inj,
                                        HttpRequestResponse rr, boolean reflected, String note) {
        HttpRequest rq = rr != null ? rr.request() : null;
        HttpResponse rs = rr != null ? rr.response() : null;
        int status = rs != null ? rs.statusCode() : -1;
        String method = rq != null ? rq.method() : "?";
        String url = rq != null ? rq.url() : "";
        return new HistoryEntry(sink.nextHistoryId(), HistoryEntry.Type.TEST, sink.moduleName(),
                technique, inj, method, url, status, CacheAnalyzer.label(rs), reflected, note, rr, parentId);
    }

    private void addFinding(ModuleSink sink, Finding.Severity sev, String technique, HttpRequest req,
                            String inj, String evidence, String cacheStatus,
                            HttpRequestResponse attack, HttpRequestResponse confirm) {
        String host, url;
        try { host = req.httpService().host(); } catch (Exception e) { host = "?"; }
        url = req.url();
        Finding f = new Finding(sink.nextFindingId(), sev, sink.moduleName(), technique, host, url,
                inj, evidence, cacheStatus, attack, confirm);
        cfg.incFindings();
        sink.addFinding(f);
    }
}
