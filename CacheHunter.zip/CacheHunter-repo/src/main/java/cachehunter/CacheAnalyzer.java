package cachehunter;

import burp.api.montoya.http.message.HttpHeader;
import burp.api.montoya.http.message.responses.HttpResponse;

import java.util.Locale;

/**
 * Interprets cache-related response headers to decide whether a response is cacheable and
 * whether a given response was served from a cache (HIT). Header set derived from the corpus
 * (X-Cache, CF-Cache-Status, Age, Via, Server-Timing cdn-cache;desc=HIT, Cache-Control, ...).
 */
public final class CacheAnalyzer {

    private CacheAnalyzer() {}

    public static String headerValue(HttpResponse resp, String name) {
        if (resp == null) return null;
        for (HttpHeader h : resp.headers()) {
            if (h.name().equalsIgnoreCase(name)) return h.value();
        }
        return null;
    }

    /** True if the response was clearly served from a shared cache. */
    public static boolean isCacheHit(HttpResponse resp) {
        if (resp == null) return false;
        for (String hn : TechniqueLibrary.CACHE_PRESENCE_HEADERS) {
            String v = headerValue(resp, hn);
            if (v == null) continue;
            String lv = v.toLowerCase(Locale.ROOT);
            if (hn.equalsIgnoreCase("Age")) {
                try { if (Integer.parseInt(v.trim()) > 0) return true; } catch (NumberFormatException ignored) {}
                continue;
            }
            for (String tok : TechniqueLibrary.CACHE_HIT_TOKENS) {
                if (lv.contains(tok)) return true;
            }
        }
        // Akamai Server-Timing
        String st = headerValue(resp, "Server-Timing");
        if (st != null && st.toLowerCase(Locale.ROOT).contains("cdn-cache") && st.toLowerCase(Locale.ROOT).contains("hit"))
            return true;
        return false;
    }

    /** Rough "MISS" signal (explicit miss token present). */
    public static boolean isCacheMiss(HttpResponse resp) {
        if (resp == null) return false;
        for (String hn : new String[]{"X-Cache","CF-Cache-Status","X-Cache-Status","X-Proxy-Cache","Cache-Status"}) {
            String v = headerValue(resp, hn);
            if (v != null && v.toLowerCase(Locale.ROOT).contains("miss")) return true;
        }
        String st = headerValue(resp, "Server-Timing");
        if (st != null && st.toLowerCase(Locale.ROOT).contains("cdn-cache") && st.toLowerCase(Locale.ROOT).contains("miss"))
            return true;
        return false;
    }

    /**
     * True if the response is (or is allowed to be) stored by a shared cache.
     * Considers Cache-Control directives, presence of cache headers, and static hints.
     */
    public static boolean isCacheable(HttpResponse resp) {
        if (resp == null) return false;
        String cc = headerValue(resp, "Cache-Control");
        if (cc != null) {
            String lc = cc.toLowerCase(Locale.ROOT);
            if (lc.contains("no-store")) return false;
            if (lc.contains("private")) {
                // private forbids shared cache; only cacheable if a shared cache header still says HIT
                return isCacheHit(resp);
            }
            if (directive(lc, "s-maxage") > 0) return true;   // shared-cache max-age (CDNs honour this first)
            if (lc.contains("public")) return true;
            int maxAge = directive(lc, "max-age");
            if (maxAge > 0) return true;
            if (lc.contains("no-cache")) {
                // no-cache = must revalidate, but can still be stored; treat as cacheable-ish only if cache headers present
                return hasAnyCacheHeader(resp);
            }
        }
        if (isCacheHit(resp)) return true;
        // Expires in the future
        if (headerValue(resp, "Expires") != null && headerValue(resp, "Age") != null) return true;
        return hasAnyCacheHeader(resp) && !hasNoStore(resp);
    }

    public static boolean hasAnyCacheHeader(HttpResponse resp) {
        for (String hn : TechniqueLibrary.CACHE_PRESENCE_HEADERS) {
            if (headerValue(resp, hn) != null) return true;
        }
        return false;
    }

    private static boolean hasNoStore(HttpResponse resp) {
        String cc = headerValue(resp, "Cache-Control");
        return cc != null && cc.toLowerCase(Locale.ROOT).contains("no-store");
    }

    /**
     * Parse a Cache-Control directive value as a token (so "max-age" is NOT matched inside
     * "s-maxage", and vice-versa). Returns the integer value, or -1 if absent/no value.
     */
    private static int directive(String lc, String name) {
        int from = 0;
        while (true) {
            int i = lc.indexOf(name, from);
            if (i < 0) return -1;
            // ensure token boundary on the left (start, comma, space, or ';')
            boolean leftOk = (i == 0) || !isTokenChar(lc.charAt(i - 1));
            int after = i + name.length();
            char c = after < lc.length() ? lc.charAt(after) : '=';
            boolean rightOk = (c == '=' || c == ' ' || c == ',' || c == ';');
            if (leftOk && rightOk) {
                int eq = lc.indexOf('=', i);
                if (eq < 0) return -1;
                int j = eq + 1;
                while (j < lc.length() && lc.charAt(j) == ' ') j++;
                StringBuilder n = new StringBuilder();
                while (j < lc.length() && Character.isDigit(lc.charAt(j))) { n.append(lc.charAt(j)); j++; }
                if (n.length() == 0) return -1;
                try { return Integer.parseInt(n.toString()); } catch (NumberFormatException e) { return -1; }
            }
            from = i + name.length();
        }
    }

    private static boolean isTokenChar(char c) {
        return Character.isLetterOrDigit(c) || c == '-';
    }

    /** Compact status word for the UI table. */
    public static String label(HttpResponse resp) {
        if (resp == null) return "-";
        if (isCacheHit(resp)) return "HIT";
        if (isCacheMiss(resp)) return "MISS";
        if (isCacheable(resp)) return "CACHEABLE";
        return "-";
    }
}
