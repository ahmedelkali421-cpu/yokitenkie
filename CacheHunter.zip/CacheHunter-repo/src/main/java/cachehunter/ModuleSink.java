package cachehunter;

/** Bridge from the engine to a module's UI (HTTP history + findings tables). */
interface ModuleSink {
    String moduleName();
    int nextHistoryId();
    int nextFindingId();
    void addOriginal(HistoryEntry e);
    void addTest(HistoryEntry e);
    void addFinding(Finding f);
}
