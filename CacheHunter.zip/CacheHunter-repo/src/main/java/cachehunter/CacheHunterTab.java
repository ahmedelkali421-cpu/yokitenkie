package cachehunter;

import burp.api.montoya.MontoyaApi;

import javax.swing.*;
import java.awt.*;

/**
 * The single top-level Burp Suite tab. Assembles the global control bar (Start/Pause/Resume/Stop,
 * custom attacker domain, request & rate limits, toggles, live counters, import buttons) and the
 * nested module tabs:  Web Cache Poisoning / Deception  ->  { Cache Poisoning, Cache Deception },
 * plus Event Log and the extracted Techniques DB.
 */
public class CacheHunterTab extends JPanel {

    private final MontoyaApi api;
    private final ScanConfig cfg;
    private final ScanEngine engine;
    private final Logger log;

    private final ModulePanel poisonPanel;
    private final ModulePanel deceptionPanel;
    private final JTextArea logArea = new JTextArea();

    private final JLabel stateLabel = new JLabel();
    private final JLabel countersLabel = new JLabel();
    private Timer counterTimer;

    public CacheHunterTab(MontoyaApi api, ScanConfig cfg, ScanEngine engine, Logger log) {
        super(new BorderLayout());
        this.api = api;
        this.cfg = cfg;
        this.engine = engine;
        this.log = log;

        this.poisonPanel = new ModulePanel("Cache Poisoning", api);
        this.deceptionPanel = new ModulePanel("Cache Deception", api);
        engine.setSinks(poisonPanel, deceptionPanel);

        add(buildControlBar(), BorderLayout.NORTH);
        add(buildTabs(), BorderLayout.CENTER);

        // wire log -> Event Log panel
        logArea.setEditable(false);
        logArea.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 12));
        log.setUiSink(line -> {
            logArea.append(line + "\n");
            javax.swing.text.Document doc = logArea.getDocument();
            if (doc.getLength() > ScanConfig.MAX_LOG_CHARS) {
                try { doc.remove(0, doc.getLength() - ScanConfig.MAX_LOG_CHARS * 3 / 4); }
                catch (Exception ignored) {}
            }
            logArea.setCaretPosition(logArea.getDocument().getLength());
        });

        startCounterTimer();
    }

    public ModulePanel poisonPanel() { return poisonPanel; }
    public ModulePanel deceptionPanel() { return deceptionPanel; }

    // =====================================================================================
    //  Control bar
    // =====================================================================================
    private JComponent buildControlBar() {
        JPanel bar = new JPanel();
        bar.setLayout(new BoxLayout(bar, BoxLayout.Y_AXIS));
        bar.setBorder(BorderFactory.createTitledBorder("Scan controls"));

        // ---- row 1: engine buttons + domain + limits + import ----
        JPanel row1 = new JPanel(new FlowLayout(FlowLayout.LEFT, 6, 3));
        JButton start  = new JButton("\u25B6 Start");
        JButton pause  = new JButton("\u23F8 Pause");
        JButton resume = new JButton("\u23F5 Resume");
        JButton stop   = new JButton("\u23F9 Stop");
        start.addActionListener(e -> engine.start());
        pause.addActionListener(e -> engine.pause());
        resume.addActionListener(e -> engine.resume());
        stop.addActionListener(e -> engine.stop());
        row1.add(start); row1.add(pause); row1.add(resume); row1.add(stop);

        row1.add(sep());
        row1.add(new JLabel("Attacker domain:"));
        JTextField domain = new JTextField(cfg.attackerDomain(), 14);
        domain.setToolTipText("Default evil.com — used as the canary in host/redirect probes");
        domain.getDocument().addDocumentListener(new SimpleDocListener(() ->
                cfg.setAttackerDomain(domain.getText())));
        row1.add(domain);

        row1.add(sep());
        row1.add(new JLabel("Request limit:"));
        JSpinner limit = new JSpinner(new SpinnerNumberModel(cfg.requestLimit(), 1, 1_000_000, 100));
        limit.addChangeListener(e -> cfg.setRequestLimit((Integer) limit.getValue()));
        limit.setPreferredSize(new Dimension(90, 26));
        row1.add(limit);

        row1.add(new JLabel("Requests/min:"));
        JSpinner rate = new JSpinner(new SpinnerNumberModel(cfg.requestsPerMinute(), 1, 100_000, 10));
        rate.addChangeListener(e -> cfg.setRequestsPerMinute((Integer) rate.getValue()));
        rate.setPreferredSize(new Dimension(80, 26));
        row1.add(rate);

        row1.add(sep());
        JButton importHist = new JButton("\u2B07 Import HTTP History");
        JButton importMap  = new JButton("\uD83D\uDDFA Import Site Map");
        JButton clear      = new JButton("\uD83D\uDDD1 Clear");
        importHist.addActionListener(e -> new Thread(engine::importProxyHistory, "import-hist").start());
        importMap.addActionListener(e -> new Thread(engine::importSiteMap, "import-map").start());
        clear.addActionListener(e -> {
            engine.clearQueue();
            poisonPanel.clearAll();
            deceptionPanel.clearAll();
            cfg.resetCounters();
        });
        row1.add(importHist); row1.add(importMap); row1.add(clear);

        // ---- row 2: toggles + counters ----
        JPanel row2 = new JPanel(new FlowLayout(FlowLayout.LEFT, 6, 3));
        JCheckBox scopeBox = new JCheckBox("Only in-scope", cfg.onlyInScope());
        scopeBox.addActionListener(e -> {
            if (!scopeBox.isSelected()) {
                int ok = JOptionPane.showConfirmDialog(this,
                        "Disabling 'Only in-scope' means Cache Hunter will send attack traffic to EVERY host\n"
                        + "in your Proxy history / Site map — including third-party domains you may not be\n"
                        + "authorised to test. Continue?",
                        "Warning — scope restriction off", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
                if (ok != JOptionPane.YES_OPTION) { scopeBox.setSelected(true); return; }
            }
            cfg.setOnlyInScope(scopeBox.isSelected());
        });
        row2.add(scopeBox);
        row2.add(check("Skip non-GET", cfg.skipNonGet(), cfg::setSkipNonGet));
        row2.add(check("Auto-watch history (3s)", cfg.autoWatch(), cfg::setAutoWatch));
        row2.add(sep());
        row2.add(check("Poisoning", cfg.probePoison(), cfg::setProbePoison));
        row2.add(check("Deception", cfg.probeDeception(), cfg::setProbeDeception));
        row2.add(check("DoS (CPDoS)", cfg.probeDos(), cfg::setProbeDos));
        JCheckBox purgeBox = new JCheckBox("PURGE (destructive)", cfg.enablePurge());
        purgeBox.setToolTipText("Sends the PURGE verb. Can flush real cache entries on path-based purge servers. Opt-in.");
        purgeBox.addActionListener(e -> {
            if (purgeBox.isSelected()) {
                int ok = JOptionPane.showConfirmDialog(this,
                        "PURGE is a state-changing verb. On servers that purge by path (ignoring the query\n"
                        + "cache-buster) it can flush a cache entry used by real users. Only enable against\n"
                        + "targets you are authorised to disrupt. Enable PURGE probing?",
                        "Warning — destructive verb", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
                if (ok != JOptionPane.YES_OPTION) { purgeBox.setSelected(false); return; }
            }
            cfg.setEnablePurge(purgeBox.isSelected());
        });
        row2.add(purgeBox);
        row2.add(check("Verbose log", cfg.verbose(), cfg::setVerbose));
        row2.add(sep());
        stateLabel.setFont(stateLabel.getFont().deriveFont(Font.BOLD));
        row2.add(stateLabel);
        row2.add(countersLabel);

        bar.add(row1);
        bar.add(row2);
        return bar;
    }

    private JComponent buildTabs() {
        JTabbedPane root = new JTabbedPane();

        // Web Cache Poisoning / Deception  -> two sub-tabs
        JTabbedPane wcpd = new JTabbedPane();
        wcpd.addTab("Cache Poisoning", poisonPanel);

        // Cache Deception sub-tab = scan view + editable extensions/delimiters
        JTabbedPane deception = new JTabbedPane();
        deception.addTab("Scan", deceptionPanel);
        deception.addTab("Extensions & Delimiters", new DeceptionConfigPanel(cfg));
        wcpd.addTab("Cache Deception", deception);

        root.addTab("Web Cache Poisoning / Deception", wcpd);
        root.addTab("Event Log", new JScrollPane(logArea));
        root.addTab("Techniques DB", new TechniqueDbPanel());
        root.addTab("Help / About", buildHelp());
        return root;
    }

    private JComponent buildHelp() {
        JTextArea a = new JTextArea();
        a.setEditable(false);
        a.setLineWrap(true);
        a.setWrapStyleWord(true);
        a.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 13));
        a.setText(HELP_TEXT);
        return new JScrollPane(a);
    }

    // =====================================================================================
    //  helpers
    // =====================================================================================
    private void startCounterTimer() {
        counterTimer = new Timer(1000, e -> {
            stateLabel.setText("  State: " + cfg.state() + "  ");
            switch (cfg.state()) {
                case RUNNING: stateLabel.setForeground(new Color(0x2E7D32)); break;
                case PAUSED:  stateLabel.setForeground(new Color(0xF57C00)); break;
                default:      stateLabel.setForeground(new Color(0xC62828));
            }
            countersLabel.setText("probes: " + cfg.probesSent()
                    + "   findings: " + cfg.findings()
                    + "   queue: " + cfg.queueSize());
        });
        counterTimer.setInitialDelay(0);
        counterTimer.start();
    }

    /** Called from the extension-unloading handler to release UI resources. */
    public void dispose() {
        if (counterTimer != null) counterTimer.stop();
    }

    private static JComponent sep() {
        JSeparator s = new JSeparator(SwingConstants.VERTICAL);
        s.setPreferredSize(new Dimension(8, 24));
        return s;
    }

    private interface BoolSetter { void set(boolean b); }

    private static JCheckBox check(String label, boolean initial, BoolSetter setter) {
        JCheckBox cb = new JCheckBox(label, initial);
        cb.addActionListener(e -> setter.set(cb.isSelected()));
        return cb;
    }

    /** Minimal document listener that runs a callback on any change. */
    private static class SimpleDocListener implements javax.swing.event.DocumentListener {
        private final Runnable r;
        SimpleDocListener(Runnable r) { this.r = r; }
        @Override public void insertUpdate(javax.swing.event.DocumentEvent e) { r.run(); }
        @Override public void removeUpdate(javax.swing.event.DocumentEvent e) { r.run(); }
        @Override public void changedUpdate(javax.swing.event.DocumentEvent e) { r.run(); }
    }

    private static final String HELP_TEXT =
            "Cache Hunter — real-time Web Cache Poisoning & Deception scanner\n" +
            "================================================================\n\n" +
            "WHAT IT DOES\n" +
            "  Watches Burp's Proxy HTTP history in real time (poll every 3s) and/or imports the\n" +
            "  Proxy history and the Target Site map. Every unique endpoint is automatically probed\n" +
            "  with every technique/payload extracted from the research corpus, and cache poisoning,\n" +
            "  cache deception and cache-poisoning DoS are auto-detected.\n\n" +
            "CONTROLS\n" +
            "  Start / Pause / Resume / Stop  — drive the engine.\n" +
            "  Attacker domain                — canary domain for host/redirect probes (default evil.com).\n" +
            "  Request limit                  — hard cap on total requests sent (safety).\n" +
            "  Requests/min                   — throttle so you never hammer a target.\n" +
            "  Only in-scope                  — restrict to Burp Target scope.\n" +
            "  Import HTTP History/Site Map   — seed targets from what Burp already knows.\n\n" +
            "TABS\n" +
            "  Cache Poisoning  — unkeyed headers/cookies, fat GET, parameter cloaking, unkeyed params, CPDoS.\n" +
            "  Cache Deception  — path-mapping/delimiter/normalization suffixes; the Extensions & Delimiters\n" +
            "                     sub-tab lets you edit the cacheable-extension and delimiter lists live.\n" +
            "  Techniques DB    — every technique/payload extracted from the 99 reports/labs.\n\n" +
            "Each module has its own HTTP history (ORIG = base request from Burp, test = generated probe).\n" +
            "Select a row to view the request/response; select a finding to jump to its attack + confirmation.\n\n" +
            "SAFETY / AUTHORISATION\n" +
            "  All poisoning/DoS proofs use a unique cache-buster query parameter, so they affect only your\n" +
            "  own cache key — not real users. Only run this against systems you are explicitly authorised to\n" +
            "  test (e.g. PortSwigger Web Security Academy labs, or targets in an authorised bug-bounty/pentest\n" +
            "  scope). You are responsible for staying within that authorisation.\n";
}
