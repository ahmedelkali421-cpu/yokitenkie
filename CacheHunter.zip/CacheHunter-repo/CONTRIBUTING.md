# Contributing

Contributions are welcome — new techniques, detection improvements, UI polish, and bug fixes.

## Getting started

1. Fork and clone the repo.
2. Build: `gradle build` (produces `build/libs/CacheHunter.jar`, copied to `dist/`).
3. Load `dist/CacheHunter.jar` in Burp → Extensions → Add → Java.
4. Test against PortSwigger Web Security Academy cache labs.

## Adding a technique

The knowledge base lives in `src/main/java/cachehunter/TechniqueLibrary.java`. To add a technique:

1. Add the payload/header/extension/delimiter to the relevant list, **with a source comment**.
2. Make sure it is actually exercised by the engine in `Scanners.java` (a list that is defined but
   never iterated is a bug — round 1 of the audit fixed three of these).
3. Add a catalogue entry so it shows up in the **Techniques DB** tab.
4. Update `docs/TECHNIQUES.md`.

## Guidelines

- **Safety first.** Every proof probe must use the cache-buster. Destructive actions must be
  opt-in. Never add large ID/host wordlists that could hit real users.
- **Bound memory.** Any new per-request storage must respect the existing ring-buffer / cap limits.
- **Thread safety.** The engine runs on worker threads; UI updates must go through the EDT
  (`SwingUtilities.invokeLater`). Don't block the EDT.
- **Be honest in docs.** If a technique is heuristic or partial, say so.

## Reporting bugs

Open an issue with: Burp version, steps to reproduce, expected vs actual behaviour, and any
relevant Event Log / Output text.
