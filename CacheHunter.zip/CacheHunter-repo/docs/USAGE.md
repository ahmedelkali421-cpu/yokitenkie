# Usage Guide

A step-by-step guide to running Cache Hunter. (نسخة عربية في الأسفل.)

## 1. Install

Burp → **Extensions → Installed → Add** → type **Java** → select `dist/CacheHunter.jar`.
The Output tab should print `Cache Hunter loaded. 101 techniques ready…` and a **Cache Hunter**
tab appears.

## 2. Configure

- **Target → Scope → Add** your target host. *Only in-scope* is on by default, so anything outside
  scope is ignored.
- In the Cache Hunter control bar:
  - **Attacker domain** — canary used in host/redirect probes (default `evil.com`).
  - **Request limit** — hard cap on total requests sent (start low, e.g. 500).
  - **Requests/min** — throttle (start low, e.g. 60).
  - Toggles: **Poisoning / Deception / DoS** (on), **PURGE** (leave off), **Only in-scope** (on).

## 3. Run

Either:
- **Automatic:** press **▶ Start**, then browse the target through Burp's browser
  (Proxy → Intercept off → Open Browser). New requests are picked up every ~3 s.
- **Manual:** press **Start**, then **⬇ Import HTTP History** and/or **🗺 Import Site Map**.

Controls: **⏸ Pause / ⏵ Resume / ⏹ Stop**, and **🗑 Clear** to empty the tables.

## 4. Read results

Open **Web Cache Poisoning / Deception**:

- **Cache Poisoning** and **Cache Deception** sub-tabs each have their own HTTP-history table:
  - `ORIG` (blue) = the base request pulled from Burp.
  - `test` = a request the engine generated (red = the canary was reflected).
- Select a row to see **Original / Tested Req+Resp**, a **Diff**, and **Techniques applied**.
- The **Findings** table shows severity (Critical/High/Medium/Low/Info); select a finding to jump
  to its attack request and confirmation request.
- **Cache Deception → Extensions & Delimiters** lets you edit the cacheable-extension and delimiter
  lists live.
- **Techniques DB** lists every extracted technique; **Event Log** is the live log.

## 5. Verify (recommended first run)

Load the extension and try a PortSwigger lab, e.g. **"Web cache poisoning with an unkeyed header"**.
Browsing the lab home page should produce a finding in the **Cache Poisoning** tab within seconds
(`Unkeyed header X-Forwarded-Host … reflected … cacheable`).

> Cache Hunter **detects** the issue. Completing a lab (marking it *Solved*) still requires the
> manual exploitation step (hosting a payload on the exploit server and poisoning the victim's
> cache) — that is expected of any scanner.

## Troubleshooting

- Nothing happens → confirm **State: RUNNING**, the target is **in scope**, and requests appear in
  **Proxy → HTTP history** (otherwise the browser isn't proxied). Try **Import HTTP History**.
- Confirm it's sending → in **Logger** / extension Output you should see outbound requests carrying
  a `cchz…` cache-buster parameter.
- Errors → check the extension's **Output/Errors** tabs.

---

## بالعربية

1. **التحميل:** Extensions → Add → Java → `dist/CacheHunter.jar`.
2. **الإعداد:** أضف النطاق في Target → Scope؛ اضبط Attacker domain (`evil.com`)، Request limit،
   Requests/min؛ اترك PURGE مطفأً.
3. **التشغيل:** اضغط **Start** ثم تصفّح الهدف عبر متصفّح Burp، أو استخدم **Import HTTP History** /
   **Import Site Map**. تحكّم: Pause/Resume/Stop/Clear.
4. **النتائج:** في تبويبَي Cache Poisoning / Cache Deception — صف `ORIG` هو الطلب الأصلي، وصفوف
   `test` هي الطلبات المولّدة؛ جدول Findings يصنّف الخطورة؛ اختر finding للقفز إلى طلب الهجوم
   والتأكيد. عدّل قوائم الامتدادات/المحدِّدات من تبويب Extensions & Delimiters.
5. **التحقّق:** جرّبها على لاب PortSwigger "Web cache poisoning with an unkeyed header" — يجب أن
   يظهر finding خلال ثوانٍ. (الأداة **تكتشف**؛ حلّ اللاب رسمياً يحتاج خطوة استغلال يدوية عبر exploit
   server.)
6. **لو لم يظهر شيء:** تأكّد أن الحالة RUNNING، والهدف داخل Scope، والطلبات تظهر في Proxy HTTP
   history؛ جرّب Import HTTP History؛ وتحقّق من Output/Errors في نافذة الإضافة.
