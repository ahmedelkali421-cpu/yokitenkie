# PRODUCTION AUDIT — Cache Hunter

تدقيق جاهزية الإنتاج (production-readiness). المعيار هنا أعلى من «تعمل»: يجب ألا تُسبّب الأداة **OOM**،
ولا أثراً جانبياً على **الكاش الحقيقي لمستخدمين حقيقيين**، ولا تعطّل واجهة Burp، وأن تُدار خيوطها ومواردها
بأمان عبر التحميل/الإلغاء. أُجري الفحص على الكود سطراً بسطر + اختبارات تشغيلية headless. كل ما هو **حرج
أُصلح** في هذه الجولة، وأُعيد بناء الـJAR والتحقق منه.

---

## 0) ملخص القرار

| الفئة | الحكم |
|---|---|
| الأمان الهجومي (لا ضرر لمستخدمين حقيقيين) | ✅ بعد الإصلاح (buster عشوائي، PURGE opt-in، تحذير scope) |
| إدارة الذاكرة (لا OOM في جلسة طويلة) | ✅ بعد الإصلاح (جداول/سجل/طابور محدودة، سقف حجم الجسم) |
| التزامن (لا تسابق/تجمّد) | ✅ مُختبَر (عدّادات ذرّية، RateLimiter صحيح، حالة ذرّية) |
| دورة حياة الموارد (تحميل/إلغاء) | ✅ (خيوط daemon تنتهي على unload، executor يُغلق) |
| معالجة الأخطاء (طلب فاشل لا يُسقط المحرك) | ✅ (catch Throwable في العمّال والـpoller) |
| صحة الكشف (heuristic) | ⚠️ استدلالي بطبيعته — يتطلّب تحقّقاً يدوياً (مصمّم لذلك) |
| التحقّق النهائي E2E ضد هدف حيّ | ⛔ يتطلّب تحميلاً في Burp (لا Burp في بيئة البناء) |

**الخلاصة:** الأداة جاهزة للاستخدام في بيئة إنتاج **مع** الإعدادات الافتراضية الآمنة، بشرط التحقّق النهائي
بتحميلها في Burp على لاب معروف قبل الاعتماد الكامل.

---

## 1) مشاكل حرجة وُجدت **وأُصلحت** في هذه الجولة

### 1.1 نمو الذاكرة بلا حدود (خطر OOM) — ✅ أُصلح
- **قبل:** جداول HTTP history وFindings كانت `ArrayList` بلا سقف، تحتفظ بكامل أجسام الطلب/الرد لكل probe إلى الأبد؛ والسجل (`JTextArea`) والطابور بلا حدود. جلسة طويلة (خصوصاً مع Request limit مرتفع) قد تستهلك مئات الميغابايتات وتُسبّب OOM.
- **بعد:**
  - `ModulePanel` الآن **ring buffer**: يحذف الأقدم بعد `MAX_TABLE_ROWS=15000` (history) و`MAX_FINDING_ROWS=5000`.
  - `Event Log` يُقلَّم عند `MAX_LOG_CHARS=300000`.
  - الطابور **محدود** بـ`MAX_QUEUE=10000` (`LinkedBlockingQueue` بسعة)؛ عند الامتلاء يُتخطّى الإدخال ويُلغى من `seen` لإتاحة إعادة المحاولة لاحقاً.

### 1.2 استهلاك CPU/ذاكرة على أجسام ضخمة/ثنائية — ✅ أُصلح
- **قبل:** `bodyToString().toLowerCase()` على كامل الجسم (قد يكون صورة/ملف عدة ميغابايت من Site map) في كل probe.
- **بعد:** `capBody()` يحلّل فقط أول `MAX_BODY_SCAN=500000` حرفاً في كل دوال الكشف (`respContainsToken`, `reflectionContext`, `markersIn`).

### 1.3 PURGE فعل مدمّر كان مُفعّلاً دائماً — ✅ أُصلح
- **قبل:** كان يُرسل `PURGE` لكل endpoint. على خوادم تُفرِغ الكاش **حسب المسار** (متجاهلةً الـquery buster) قد يُفرِغ إدخالاً يستخدمه مستخدمون حقيقيون.
- **بعد:** PURGE خلف خيار **`enablePurge` (افتراضياً OFF)** مع **نافذة تأكيد تحذيرية** عند تفعيله.

### 1.4 خطر مهاجمة أهداف غير مقصودة — ✅ أُصلح/خُفِّف
- `Only in-scope` افتراضياً **ON**. عند محاولة إيقافه تظهر **نافذة تحذير** صريحة بأن الأداة ستهاجم كل مضيف في الـProxy history/Site map.

### 1.5 تصادم الـcache-buster مع مفاتيح حقيقية — ✅ خُفِّف
- **قبل:** اسم ثابت `cbust`؛ لو استخدمه الهدف كبارامتر مُفهرَس نظرياً قد يؤثّر على مستخدمين.
- **بعد:** اسم **عشوائي** لكل probe (`cchz<rand>=<rand>`) — احتمال التصادم ≈ صفر.

### 1.6 بناء غير آمن ضد null — ✅ أُصلح
- الـpoller والاستيراد الآن يتخطّيان إدخالات الـProxy التي بلا `finalRequest()`/`originalResponse()` بدل الاعتماد على استثناء.

---

## 2) نتائج الاختبارات التشغيلية (headless)

نُفّذت على الكود الفعلي (لا نسخ):

```
[counters] probes=400000/400000  findings=400000  queue=0     thread-safe: true      (8 threads × 50k)
[rate]     120 sends in 1217ms   (>= ~1190ms)     rate never exceeds rpm: true       (4 workers, rpm=6000)
[queue]    cap=100 accepted=100 dropped=150       bounded OK: true
[state]    RUNNING/PAUSED/STOPPED transitions: true
[safety]   PURGE default off: true    onlyInScope default on: true
[addBuster]/[collapseSlashes]/[deception templates]  100 unique, 0 malformed, 0 missing-base, root '/' OK
[contract] implements BurpExtension: true   instantiates OK: true   techniques: 101   JAR valid
[packaging] no burp.api.montoya classes bundled (Burp provides them at runtime)
javac: 0 errors (only benign Swing serial/this-escape warnings)
```

---

## 3) التزامن ودورة الحياة (تحليل)

- **العدّادات/الحالة:** `AtomicInteger`/`AtomicReference` — مُختبَرة تحت 8 خيوط بلا فقد.
- **RateLimiter:** `synchronized acquire()` يفرض تباعداً عالمياً = `60000/rpm` ملّي ثانية؛ مع عدة عمّال لا يتجاوز المعدّل المطلوب أبداً (مُختبَر). (ملاحظة: ينام داخل القفل عمداً لتسلسل الإرسال — مقبول ومقصود.)
- **Pause/Stop:** `Sender.send` ينتظر أثناء PAUSE (قبل حجز المعدّل، فلا يحتجز قفلاً)، ويُعيد null عند STOP.
- **حدّ الطلبات:** يُرمى `LimitReachedException` من `Sender`، يُلتقط في حلقة العامل ← `stopFromLimit()` (قد يتجاوز الحدّ بـ1-2 فقط بسبب سباق حميد).
- **الإلغاء (unload):** `registerUnloadingHandler(engine::shutdown)` ← `alive=false` (العمّال daemon ينتهون خلال ≤200ms) + `poller.shutdownNow()`. لا تسرّب خيوط. إعادة التحميل تُنشئ نسخة جديدة نظيفة.
- **متانة العامل:** `catch (Throwable)` — طلب فاشل واحد لا يُسقط العامل.

---

## 4) الأمان الهجومي (ضمانات عدم الإضرار)

- **كل** probe إثبات يضيف **cache-buster عشوائياً** ← يصيب مفتاح الكاش الخاص بالأداة فقط، لا مستخدمين حقيقيين.
- الطلبات المولّدة تُرسَل عبر `api.http().sendRequest` (لا تمرّ عبر الـProxy) ← **لا حلقة تغذية راجعة** (الـpoller لا يراها).
- كوكيز الجلسة تذهب إلى الهدف الأصلي فقط؛ الـcanary (`token.evil.com`) يوضع في **قيمة header** ولا يُسرّب كوكيز إلى evil.com.
- تعديل `Host: host:31337` لا يغيّر توجيه الاتصال (يظل إلى `httpService` الحقيقي) — يُختبر الانعكاس فقط.
- **الأفعال المدمّرة (PURGE) opt-in**؛ **خارج النطاق** يتطلّب تأكيداً؛ **الحدّ الأقصى للطلبات + req/min** يمنعان الإرهاق.
- **توصية تشغيل:** استخدم **حساب اختبار منخفض الصلاحيات** عند فحص الخداع (الأداة تُخزّن رد جلستها في الكاش تحت مفتاح buster خاص بها).

---

## 5) قيود متبقية (بصراحة — لا حاصرة للإنتاج مع الافتراضات الآمنة)

1. **الكشف استدلالي:** يُبلّغ عن **مرشّحين** (انعكاس + قابلية تخزين/تشابه)؛ يحتمل false positive/negative. كل finding يعرض طلب الهجوم + طلب التأكيد للمراجعة اليدوية.
2. **لا مهلة صريحة لكل طلب:** `sendRequest` يعتمد على مهلات شبكة Burp من إعدادات المشروع؛ endpoint معلّق قد يشغل عاملاً (العامل الآخر يستمر). يُنصح بضبط timeouts معقولة في Burp.
3. **إنشاء محرّرات Burp داخل `initialize` (خيط Burp لا EDT):** ممارسة شائعة ومقبولة في إضافات Montoya، لكنها ليست على EDT حرفياً.
4. **تقنيات خاصة بمنصّات محددة غير مؤتمتة** (موثّقة في `TECHNIQUES.md`): Sitecore HTML cache poisoning، Apache Traffic Server fragment (CVE-2021-27577)، كشف host-header casing التلقائي، 403-buckets عبر Authorization، والتسميم عبر **HTTP Request Smuggling / single-packet race** (تقرير Basecamp — مجال أدوات smuggling منفصلة).
5. **إزالة التكرار حسب endpoint** (`method+host+path` بلا query): الطلب المتكرّر حرفياً يُفحص مرة واحدة (لتجنّب الحلقات).
6. **لم يُختبَر E2E ضد هدف حيّ هنا** (لا Burp في بيئة البناء). **التحقّق النهائي الموصى به قبل الاعتماد:** حمّل الـJAR في Burp وشغّله على لاب PortSwigger مثل «Web cache poisoning with an unkeyed header» و«Web cache deception» labs، وراقب ظهور النتائج والطلبات في history الأداة.

---

## 6) قائمة تحقّق ما قبل النشر (Pre-deployment checklist)

- [x] لا OOM في جلسة طويلة (جداول/سجل/طابور/جسم محدودة).
- [x] الأفعال المدمّرة opt-in، والافتراضات آمنة (PURGE off، scope on).
- [x] cache-buster عشوائي على كل probe.
- [x] التزامن مُختبَر (عدّادات، معدّل، حالة).
- [x] تنظيف الخيوط/الـexecutor على الإلغاء.
- [x] متانة ضد الأخطاء (catch Throwable).
- [x] JAR صالح، يُنفّذ BurpExtension، بلا تضمين montoya.
- [ ] **(عليك)** التحقّق النهائي بتحميلها في Burp على لاب معروف.
- [ ] **(عليك)** ضبط timeouts الشبكة في إعدادات مشروع Burp.
- [ ] **(عليك)** التأكد من التفويض القانوني للأهداف قبل التشغيل.

---

## 7) الإصدار

- الكتالوج: **101 تقنية**، كل قوائم التقنيات مُستخدَمة فعلياً (تحقّق آلي).
- حدود الإنتاج: `MAX_TABLE_ROWS=15000`, `MAX_FINDING_ROWS=5000`, `MAX_QUEUE=10000`, `MAX_LOG_CHARS=300000`, `MAX_BODY_SCAN=500000`.
- خيارات أمان جديدة: `Only in-scope` (تحذير عند الإيقاف)، `PURGE (destructive)` (opt-in بتأكيد).
