# AUDIT — Cache Hunter (تدقيق شامل)

تدقيق صادق للأداة مقابل (أ) كل ما طلبته، و(ب) كل ما استُخرج من التقارير. أُجري بفحص الكود سطراً بسطر،
وليس مجرّد مراجعة سطحية. الأخطاء/الثغرات التي وُجدت **أُصلحت في هذه الجولة** وأُعيد بناء الـJAR.

---

## 1) جدول مطابقة المتطلبات (طلبك ← ما نُفّذ)

| # | ما طلبته | الحالة | أين في الكود / كيف |
|---|---|---|---|
| 1 | استخراج **كل** تقنية/methodology/payload من الأرشيف | ✅ | `TECHNIQUES.md` + `TechniqueLibrary.java` (**101 تقنية** في الكتالوج) |
| 2 | إضافة Burp تجد WCP + WCD **في الوقت الفعلي وآلياً** | ✅ | `ScanEngine`: poller يقرأ `proxy().history()` كل 3 ثوانٍ + خيطا عمل |
| 3 | أزرار **Start / Pause / Resume / Stop** | ✅ | `CacheHunterTab` شريط التحكّم ← `engine.start/pause/resume/stop` |
| 4 | **Custom domain** مع `evil.com` افتراضياً | ✅ | `ScanConfig.attackerDomain` + حقل النص (DocumentListener) |
| 5 | يمسك أي request في HTTP history ويطبّق **كل** التقنيات حرفياً | ✅ | poller + `scanPoison`/`scanDeception` يطبّقان كل القوائم |
| 6 | **Request limit** + **Requests/min** | ✅ | `ScanConfig` + `RateLimiter` + `Sender` (يحترمهما قبل كل إرسال) |
| 7 | نظام **detection** يخبرك بوجود ثغرة | ✅ | `Finding` + تصنيف خطورة + جدول Findings لكل أداة |
| 8 | **لا تنسَ شيئاً** / الأولوية للاستخراج | ✅ (بعد الإصلاح) | انظر §3 — أُصلحت 3 قوائم كانت غير مُستخدَمة + رُفعت السقوف |
| 9 | «اضغط زر» لاستخراج المعلومة من تقارير MHTML | ✅ | تمّ فعلياً وقت الاستخراج: `bsdtar` + `mhtml2text.py` على 99 ملف |
| 10 | تبويب واحد **"WCP/Deception"** بداخله تبويبان (Poisoning + Deception) | ✅ | `CacheHunterTab.buildTabs()` (JTabbedPane متداخل) |
| 11 | في Cache Deception: أضف **الامتدادات** من قاعدة البيانات | ✅ | `DeceptionConfigPanel` (قابلة للتعديل، مُعبّأة من قائمة CF/Akamai + `.avif`) |
| 12 | اسحب الملفات الستاتيكية من **Site Map** | ✅ | زر **Import Site Map** ← `engine.importSiteMap()` (`api.siteMap()`) |
| 13 | كل request يُطبّق عليه كل التقنيات **بدون استثناء** | ✅ (بعد الإصلاح) | أُزيلت السقوف الضيّقة؛ الآن السقف الأمني الوحيد هو **Request limit** |
| 14 | لكل أداة **HTTP history** فيه الطلب الأصلي + الطلبات المُختبَرة | ✅ | `ModulePanel` لكل أداة: صف **ORIG** + صفوف **test** + عارض Req/Resp |
| 15 | واجهة تشبه الصورة | ✅ | شريط تحكّم علوي + جداول + تبويبات + عارض طلب/رد + سجل + عدّادات حيّة |

---

## 2) تغطية التقنيات مقابل التقارير

### Web Cache Poisoning — مُنفّذ كـprobes فعّالة
- **Host/URL headers:** `X-Forwarded-Host, X-Host, X-Forwarded-Server, X-Forwarded, Forwarded, X-Original-Host, X-Forwarded-For, True-Client-IP, Client-IP, X-Real-IP, X-Custom-IP-Authorization` + URL-override (`X-Original-URL, X-Rewrite-URL, X-Override-URL, X-Forwarded-Path/Prefix/URI/URL`).
- **Scheme combos (open redirect):** `X-Forwarded-Scheme/Proto/Protocol/SSL, X-Url-Scheme, Front-End-Https` مدموجة مع X-Forwarded-Host.
- **Cookies:** `language, locale, country, region, currency, fehost, hav, n_vis, session_id, theme, utm, ref`.
- **Fat GET** (body param يتجاوز URL param).
- **Parameter cloaking** (دمج `?` + فاصلة منقوطة Rails).
- **Unkeyed query params:** كامل القائمة (`utm_*, gclid, fbclid, mc_cid, mc_eid, callback, jsonp, cb, _`).
- **Cache-key injection (جديد):** unkeyed port عبر `Host: host:31337`، وبارامتر مكرّر مُرمَّز (`p%65=0`).
- **Port injection (جديد):** `X-Forwarded-Port` غير رقمي ← XSS، ورقمي ← منفذ ميّت (DoS).
- **Cache-key oracle (جديد):** `Pragma: akamai-x-get-cache-key` ← يكشف `X-Cache-Key`.
- **PURGE (جديد):** كشف قبول فعل PURGE (أداة إعادة تسميم).
- **Vary (جديد):** يُدرَج في دليل النتيجة لاستهداف ضحايا بقيمة معيّنة.

### Web Cache Deception — مُنفّذ
- **امتدادات ستاتيكية:** 65 امتداداً (قائمة CloudFlare/Akamai كاملة) + `.avif` لتجاوز Cache Deception Armor.
- **Path mapping (REST):** `/{B}/wcd.js`, `/{B}/nonexistent.css`.
- **Delimiters:** `;` (Spring)، `.` (Rails)، `%00` (OpenLiteSpeed)، `%0a/%0d` (Nginx)، `%23`، `%3f`، `%09`، `%3b`، `%2e` — مُرمَّزة وغير مُرمَّزة.
- **Normalization/traversal:** `/{DIR}/..%2f{B}`, `%2e%2e%2f`, `..%5c`, `..%255c`.
- **Static directories:** `static, assets, resources, public, content, media, images, img, js, css, fonts, dist, build, cdn-cgi, _next, wp-content, sites/files`.
- **منهجية التأكيد:** الأصل يتجاهل اللاحقة + الرد قابل للتخزين، ثم طلب **مجهول** يسترجع محتوى الضحية = Critical.

### CPDoS — مُنفّذ
HMC (backslash/meta chars)، HMO (**method override** عبر القائمة المخصّصة الآن)، HHO (header ~8KB)، Transfer-Encoding، Range، Accept-Encoding (+underscore)، Accept، X-Forwarded-SSL، **X-Forwarded-Port dud** (قائمة مخصّصة الآن)، Max-Forwards، Upgrade، Content-Type، وquery primitives (NULL bytes، param arrays، oversize).

---

## 3) الثغرات التي وُجدت في التدقيق ✅ **وأُصلحت**

| الثغرة | الأثر | الإصلاح |
|---|---|---|
| `PORT_HEADERS` معرّفة لكن **غير مستخدمة** كـprobe | لا اختبار port-XSS ولا dud-port | حلقات مخصّصة في `scanKeyAndMisc` (XSS) و`scanDos` (dud port) |
| `METHOD_OVERRIDE_HEADERS` معرّفة لكن **غير مستخدمة** كقائمة | تغطية method-override ناقصة | حلقة مخصّصة في `scanDos` تكرّر القائمة كاملةً |
| `CACHE_KEY_ORACLE_PRAGMAS` معرّفة لكن **غير مستخدمة** | لا كشف لمفتاح الكاش | probe جديد يرسل الـPragmas ويقرأ `X-Cache-Key` |
| سقف **6** فقط على unkeyed query params | تُهمَل بارامترات | أصبح يكرّر **كل** القائمة |
| توقّف الخداع بعد **3 نتائج** لكل endpoint | نتائج مفقودة | أُزيل — يُبلّغ عن **كل** النتائج |
| الخداع: أول 3 قوالب فقط تأخذ كل الامتدادات | تغطية ضيّقة | الآن **كل** قالب يأخذ كل الامتدادات ذات الأولوية (السقف 500، والحدّ الفعلي هو Request-limit) |
| Cache-key injection (unkeyed port/host، encoded param) مذكورة في الوثائق لكن **غير مُنفّذة** | نقص تغطية | نُفّذت في `scanKeyAndMisc` |
| PURGE (في 6 تقارير) غير مُنفّذ | نقص | probe كشف PURGE جديد |

**بعد الإصلاح:** لا توجد أي قائمة تقنيات معرّفة وغير مُستخدَمة (تُحقّق آلياً)، والكتالوج = 101.

---

## 4) قيود معروفة (بصراحة)

هذه إمّا خارج نطاق أداة كهذه، أو خاصة بتطبيقات محدّدة، أو تتطلّب تحقّقاً يدوياً:

1. **الكشف استدلالي (heuristic):** الأداة تُبلّغ عن **مرشّحين** (انعكاس + قابلية تخزين/تشابه أجسام)، وقد تُنتج false positive/negative. التحقّق النهائي يدوي (لهذا يعرض كل finding طلب الهجوم + طلب التأكيد).
2. **تشابه الأجسام في الخداع** يعتمد على (طول ضمن نطاق + مؤشّرات حسّاسة مشتركة) — قد يخطئ في صفحات ديناميكية جداً.
3. **تقنيات خاصة بمنصّات محددة غير مؤتمتة** (مذكورة في `TECHNIQUES.md` لكنها تحتاج سياقاً يدوياً): Sitecore HTML cache poisoning، Apache Traffic Server fragment (CVE-2021-27577)، كشف **host-header casing** التلقائي (نُفّذ port لكن ليس مقارنة حالة الأحرف)، 403 على buckets عبر Authorization، وتسميم عبر **HTTP Request Smuggling / single-packet race** (تقرير Basecamp) — هذا مجال أدوات smuggling منفصلة.
4. **إزالة التكرار حسب endpoint:** الطلبات المتطابقة (`method+host+path` بدون query) تُفحَص **مرة واحدة** لتجنّب حلقات لا نهائية. مقصود، لكن معناه أن طلباً مكرّراً حرفياً لا يُعاد فحصه.
5. **الخداع يتطلّب رد أساس = 200** بجسم غير فارغ (يتخطّى 3xx/401 كأساس).
6. **لم يُختبَر ضد هدف حيّ داخل هذه البيئة** (لا Burp هنا). التحقّق تمّ عبر: ترجمة ناجحة، فحص reflection أن نقطة الدخول تُنفّذ `BurpExtension`، وتهيئة الكائن. **التحقّق النهائي الموصى به:** حمّل الـJAR في Burp وشغّله على لاب PortSwigger مناسب (مثل "Web cache poisoning with an unkeyed header").

---

## 5) أدلّة التحقّق (هذه الجولة)

```
implements BurpExtension : true
instantiates OK          : true
techniques catalogued    : 101
port headers             : 1     (مُستخدَمة الآن في probe + DoS)
method-override headers  : 3     (مُستخدَمة الآن في DoS)
cache-key oracle pragmas : 6     (مُستخدَمة الآن في probe)
delimiter templates      : 17
static extensions        : 65
JAR integrity            : valid
FINAL unused-list check  : (none) — كل قائمة تقنيات مُستخدَمة
javac                    : 0 errors, 31 classes
```

---

## 6) الخلاصة

- **كل بنود طلبك الـ15 محقّقة.**
- **كل تقنيات/الـpayloads الرئيسية المستخرَجة مُطبَّقة الآن كـprobes فعّالة** (بعد إصلاح 3 قوائم كانت خامدة ورفع السقوف).
- القيود المتبقية موثّقة بصراحة أعلاه، ومعظمها إمّا يدوي بطبيعته أو خارج نطاق أداة كشف الكاش.
