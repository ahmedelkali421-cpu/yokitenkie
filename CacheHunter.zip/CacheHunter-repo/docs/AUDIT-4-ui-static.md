# AUDIT ROUND 4 — Cache Hunter (تدقيق شامل جديد)

تمريرة رابعة ركّزت على ما لم يُدقَّق سطراً بسطر سابقاً: **طبقة الواجهة (UI)** ودورة حياة مواردها، +
**مسح ثابت (static analysis)** لأنماط الأخطاء الشائعة عبر كل الملفات، + فحص تراجع كامل.

> **إفصاح صريح:** هذه رابع جولة تدقيق. الجولات السابقة عالجت القضايا الوظيفية والإنتاجية ودقّة الكشف.
> هذه الجولة وجدت **مشكلتين بسيطتين في دورة حياة الواجهة** (أُصلحتا)، والمسح الثابت **نظيف**. نحن الآن
> عند **العائد المتناقص** للتدقيق الساكن: الخطر المتبقّي الأساسي هو ما لا يمكن كشفه إلا بالتشغيل الحيّ داخل
> Burp ضد أهداف حقيقية (E2E)، وهو غير متاح في بيئة البناء هذه.

---

## 0) الحكم

| المحور | الحالة |
|---|---|
| طبقة الواجهة (منطق الاختيار/الـdiff/العارض) | ✅ مُدقّقة — محميّة (bounds + null) |
| دورة حياة موارد الواجهة (Timer/ids) | ✅ بعد إصلاح مشكلتين |
| مسح ثابت (استثناءات/casts/NPE/حلقات/EDT) | ✅ نظيف |
| فحص تراجع (كل الجولات 1–3) | ✅ لا تراجع |
| تحقّق E2E حيّ | ⛔ يتطلّب Burp (خارج بيئة البناء) |

**النتيجة:** لا مشاكل حاصرة جديدة. الأداة تبقى **جاهزة للإنتاج** بالإعدادات الآمنة، بانتظار تحقّق E2E.

---

## 1) مشاكل جديدة وُجدت **وأُصلحت** (دورة حياة الواجهة)

### 1.1 `clearAll()` كان يصفّر عدّادات المعرّفات أثناء عمل العمّال — ✅ أُصلح
- **الأثر:** زر Clear يمسح الطابور فقط (لا يوقف المحرك). لو ضُغط أثناء المسح، كان `historyIds/findingIds` يُصفّران إلى 0 بينما عامل ما زال يولّد صفوفاً بمعرّفات قديمة ← تصادم معرّفات يجعل `findById(parentId)` يربط صف اختبار بأصل **خاطئ** في العرض (خلل عرض، لا انهيار/أمان).
- **الإصلاح:** إزالة التصفير — المعرّفات تبقى **تصاعدية دائماً** فتُضمن فرادتها حتى مع صفوف قيد التنفيذ أثناء Clear.

### 1.2 مؤقّت العدّادات لا يُوقَف عند الإلغاء — ✅ أُصلح
- **الأثر:** `javax.swing.Timer` (كل ثانية) كان يستمر بعد unload الإضافة، ممسكاً بمراجع عناصر الواجهة ← تسريب ذاكرة بسيط + هدر CPU، ويتراكم مع إعادة التحميل المتكرّرة.
- **الإصلاح:** حُفظ المؤقّت كحقل، وأُضيفت `CacheHunterTab.dispose()` توقفه، وسلسلة الإلغاء صارت: `engine.shutdown()` **+** `tab.dispose()`.

---

## 2) نتائج المسح الثابت (static analysis) — نظيف

| الفحص | النتيجة |
|---|---|
| استثناءات مُبتلعة (`catch {}`) | 3 فقط، كلها حميدة: parsing لـAge، تقليم السجل، ضبط عارض UI |
| casts غير آمنة | لا يوجد (فقط `(Integer)` من SpinnerNumberModel — آمن دائماً) |
| NPE على `.request()/.response()` بلا حماية | لا يوجد (كلها محميّة) |
| `System.out` / `printStackTrace` | لا يوجد (كل التسجيل عبر `Logger`) |
| حلقات لا نهائية | `directive()` فيه `while(true)` لكنه **ينتهي دائماً** (مُختبَر ضد مدخلات خبيثة: 25ms) |
| `Thread.sleep` على EDT | لا يوجد (كلها على خيوط العمّال/المعدّل) |

---

## 3) فحص تراجع (الجولات 1–3) — كلها ✅

```
[counters]  thread-safe: true          [rate] respected: true          [queue] bounded OK: true
[state]     RUNNING/PAUSED/STOPPED: true
[safety]    PURGE default off: true     onlyInScope default on: true
[deception] variants PASS + root '/' PASS
[cache]     ALL DIRECTIVE TESTS: PASS   (s-maxage/max-age token-aware)
[auth]      stripAuth removes 21 headers incl X-Auth-Token: true
[parser]    adversarial directive termination: no hang (25ms)
[contract]  implements BurpExtension: true   instantiates OK: true   techniques: 101
[unload]    chain = engine.shutdown() + tab.dispose()
javac: 0 errors, 31 classes.  JAR: 68KB valid, no montoya bundled.
```

---

## 4) سجل كل ما أُصلح عبر الجولات الأربع

| الجولة | ما وُجد وأُصلح |
|---|---|
| 1 — وظيفي | 3 قوائم تقنيات خامدة فُعِّلت؛ Cache-key injection + PURGE + oracle مضافة؛ رفع السقوف. |
| 2 — إنتاج | OOM (جداول/سجل/طابور/جسم محدودة)؛ PURGE opt-in؛ buster عشوائي؛ تحذير scope؛ null-safety. |
| 3 — نهائي | خطأ `s-maxage` (false negative)؛ تجريد auth ناقص (false positive CRITICAL). |
| 4 — واجهة | تصفير المعرّفات أثناء Clear؛ عدم إيقاف مؤقّت الواجهة عند الإلغاء. |

---

## 5) الخطر المتبقّي (بصراحة)

كل ما تبقّى **لا يُكشف إلا بالتشغيل الحيّ** أو هو **قرار تصميمي مقصود**، وليس خطأً قابلاً للإصلاح ساكناً:

1. **الكشف استدلالي:** يُبلّغ عن **مرشّحين** (يبقى احتمال FP/FN؛ كل finding يرفق طلب الهجوم + التأكيد للمراجعة اليدوية).
2. **لا مهلة صريحة لكل طلب** (يعتمد على مهلات مشروع Burp).
3. **إنشاء محرّرات Burp داخل `initialize`** (خيط Burp لا EDT) — عرف مقبول في Montoya.
4. **تقنيات خاصة بمنصّات محددة غير مؤتمتة** (Sitecore، ATS CVE-2021-27577، host-casing، 403-buckets، التسميم عبر HTTP Request Smuggling) — موثّقة في `TECHNIQUES.md`.
5. **إزالة التكرار حسب endpoint** (تصميم مقصود لتجنّب الحلقات).
6. **CopyOnWriteArrayList clear+addAll غير ذرّي** في `DeceptionConfigPanel.apply()` — نافذة زمنية دقيقة قد يقرأ فيها المسح قائمة جزئية (أثر: endpoint واحد ربما بمتغيّرات أقل لحظياً). أثر ضئيل جداً، مقبول.

---

## 6) لماذا نحن عند العائد المتناقص

- الجولات الأربع غطّت: المنطق الوظيفي، السلامة الهجومية، الذاكرة/التزامن/دورة الحياة، دقّة الكشف، وطبقة الواجهة.
- المسح الثابت الأخير **لم يجد** أخطاء برمجية جديدة (فقط مشكلتي دورة حياة بسيطتين، أُصلحتا).
- ما تبقّى إمّا **استدلالي بطبيعته** (يحتاج حكماً بشرياً)، أو **يتطلّب بيئة تشغيل حيّة** (Burp + هدف)، أو **قرارات تصميم مقصودة**.
- **التوصية:** بدل تدقيق ساكن خامس، انتقل إلى **التحقّق الحيّ (E2E)** — هو الآن أعلى مصدر للقيمة.

---

## 7) قائمة التحقّق النهائية الوحيدة المتبقّية (تشغيل حيّ — عليك)

- [ ] حمّل `CacheHunter.jar` في Burp: Extensions → Installed → Add → Java.
- [ ] لابات **Poisoning** (يجب أن تظهر findings في تبويب Cache Poisoning):
  - Web cache poisoning with an unkeyed header / unkeyed cookie / multiple headers.
  - Web cache poisoning via a fat GET request / parameter cloaking / unkeyed query string.
  - Targeted web cache poisoning using an unknown header.
- [ ] لابات **Deception** (تبويب Cache Deception):
  - Exploiting path mapping / path delimiters / origin & cache server normalization / exact-match rules.
- [ ] راقب: ظهور صف ORIG + صفوف test لكل endpoint، وتصنيف الخطورة، وعدم تجمّد الواجهة.
- [ ] اضبط timeouts الشبكة في إعدادات المشروع؛ تأكّد من التفويض القانوني؛ استخدم حساباً منخفض الصلاحيات للخداع.

---

## 8) الإصدار

101 تقنية · محلّل كاش دقيق (s-maxage/max-age token-aware) · تأكيد خداع مجهول (21 auth header) ·
حدود إنتاج (table 15k/findings 5k/queue 10k/log 300k/body 500k) · أمان (scope-on+تحذير، PURGE opt-in،
buster عشوائي، request-limit+req/min) · دورة حياة نظيفة (unload = shutdown + dispose) · JAR 68KB صالح.
