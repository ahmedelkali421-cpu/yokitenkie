# Cache Hunter 🎯

**A real-time Burp Suite extension that automatically detects Web Cache Poisoning, Web Cache Deception and Cache-Poisoning DoS (CPDoS).**

Cache Hunter watches Burp's Proxy HTTP history (and/or your Target Site map) in real time, and applies **101 techniques/payloads** — distilled from ~99 security research reports, PortSwigger labs, HackTricks, PayloadsAllTheThings and ~60 HackerOne reports — to every unique endpoint, then classifies findings by severity.

Built on the **Montoya API** (Java). Java-side only — no external services.

> ⚠️ **Authorized testing only.** This tool sends attack traffic. Use it exclusively against systems you own or are explicitly authorised to test (e.g. PortSwigger Web Security Academy labs, or targets inside an authorised bug-bounty / pentest scope). See [SECURITY.md](SECURITY.md).

---

## Features

- **Real-time engine** — polls Proxy history every few seconds; also imports Proxy history and the **Target Site map** on demand (so scanning targets real endpoints, not random paths).
- **Full control** — Start / Pause / Resume / Stop, custom attacker domain (default `evil.com`), **request limit** and **requests/minute** throttle.
- **Two modules under one tab** — *Web Cache Poisoning / Deception* → **Cache Poisoning** and **Cache Deception** sub-tabs.
- **Per-module HTTP history** — every module shows the **original** request (pulled from Burp) plus every **generated test** request, with request/response viewers, a diff, and a "techniques applied" view.
- **Editable deception lists** — the CloudFlare/Akamai cacheable-extension list, delimiters, static directories and sensitive markers are all editable live.
- **Detection engine** — severity-classified findings (Critical / High / Medium / Low / Info) with the attack request and a confirmation request attached to each.
- **Techniques covered:**
  - *Poisoning:* unkeyed host/scheme/port/URL-override headers, scheme-combo open redirects, unkeyed cookies, fat GET, parameter cloaking, unkeyed query params, cache-key injection (unkeyed port / encoded param), cache-key oracle (Akamai `Pragma`), Vary awareness.
  - *Deception:* static extensions (incl. `.avif` armor bypass), path mapping, per-framework delimiters (`;` `.` `%00` `%0a` `%23` `%3f` …), normalization/traversal, static directories, anonymous-retrieval confirmation.
  - *CPDoS:* HHO / HMC / HMO, method override, dud port, bad `Transfer-Encoding` / `Range` / `Accept-Encoding`, oversized headers, malformed query.

---

## Install (prebuilt)

1. Burp → **Extensions** → **Installed** → **Add**.
2. **Extension type:** `Java`.
3. **Select file:** [`dist/CacheHunter.jar`](dist/CacheHunter.jar).
4. **Next** → the Output tab should print `Cache Hunter loaded. 101 techniques ready…`.
5. A new top-level **Cache Hunter** tab appears.

Requires **Burp Suite 2023.x or newer** (Montoya API). Works in Community and Pro.

## Usage (quick start)

1. **Target → Scope → Add** your target (needed because *Only in-scope* is on by default).
2. In the **Cache Hunter** tab set a low **Request limit** and **Requests/min** to start; leave **PURGE** off.
3. Press **▶ Start**, then browse the target through Burp's browser — or use **Import HTTP History** / **Import Site Map**.
4. Read results in the **Cache Poisoning** / **Cache Deception** sub-tabs: `ORIG` rows are base requests, `test` rows are generated probes; the **Findings** table lists issues by severity.

Full guide: [docs/USAGE](README.md) · Technique reference: [docs/TECHNIQUES.md](docs/TECHNIQUES.md).

## Build from source

Requires JDK 17+.

**Gradle** (pulls Montoya from Maven Central):
```bash
gradle build          # produces build/libs/CacheHunter.jar and copies it to dist/
```

**Manual (javac)** — if Maven Central is blocked, compile against the Montoya source:
```bash
git clone --depth 1 https://github.com/PortSwigger/burp-extensions-montoya-api.git montoya
javac -d montoya/out $(find montoya/src/main/java -name '*.java') && (cd montoya/out && jar cf ../../montoya-api.jar .)
javac -d build -cp montoya-api.jar $(find src -name '*.java')
cd build && printf 'Manifest-Version: 1.0\nBurp-Extension-Class: cachehunter.CacheHunterExtension\n' > m.txt && jar cfm ../CacheHunter.jar m.txt cachehunter
```

---

## Safety design

- Every proof-of-concept probe uses a **unique random cache-buster**, so it only affects the tool's own cache key — never real users.
- **Only in-scope** on by default (warns if disabled); the destructive **PURGE** verb is **opt-in** with a confirmation.
- Built-in **memory bounds** (ring-buffered tables, trimmed log, bounded queue, capped body analysis) and clean resource teardown on unload.
- **Requests/min** + **Request limit** are the real throttles.

See [docs/](docs/) for the four-round audit trail (functional, production, detection-accuracy, UI/static-analysis).

## Project layout

```
src/main/java/cachehunter/   # extension source (Montoya API, Java)
dist/CacheHunter.jar         # prebuilt extension
docs/TECHNIQUES.md           # extracted knowledge base (with sources)
docs/AUDIT-*.md              # audit reports
build.gradle                 # Gradle build
```

## Disclaimer

Provided as-is under the [MIT License](LICENSE), for **authorised security testing and research only**. Detection is heuristic — findings are candidates to verify manually, not guarantees. The authors accept no liability for misuse.

---

## بالعربية

**Cache Hunter** إضافة Burp تكتشف تلقائياً وفي الوقت الفعلي ثغرات **Web Cache Poisoning** و**Deception** و**CPDoS**. تلتقط أي request يدخل الـHTTP history وتطبّق عليه **101 تقنية** مستخرَجة من ~99 تقريراً/لاباً، ثم تصنّف النتائج حسب الخطورة.

- **التحميل:** Burp → Extensions → Add → Java → `dist/CacheHunter.jar`.
- **التشغيل:** أضف النطاق للـScope، اضبط Request limit / Req-min، اضغط **Start**، وتصفّح الهدف (أو Import History / Site Map).
- **الأمان:** كل probe يستخدم cache-buster عشوائياً؛ Only-in-scope افتراضي؛ PURGE اختياري بتأكيد؛ حدود ذاكرة مدمجة.
- **التوثيق:** قاعدة المعرفة الكاملة في [`docs/TECHNIQUES.md`](docs/TECHNIQUES.md)، وتقارير التدقيق في [`docs/`](docs/).

> ⚠️ للاستخدام **المصرَّح به فقط** (لابات PortSwigger أو نطاق bug-bounty/pentest مصرّح). الكشف استدلالي — النتائج مرشّحات للتحقّق اليدوي.
